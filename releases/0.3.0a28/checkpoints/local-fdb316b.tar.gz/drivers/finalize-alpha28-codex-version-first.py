import hashlib, io, json, subprocess, sys, tarfile, xml.etree.ElementTree as ET
from pathlib import Path
repo=Path('F:/syuc/agentsync-execution-intent');out=Path(sys.argv[1])
r=json.loads((out/'result.json').read_text(encoding='utf-8'));sha=r['commit']
assert r['passed'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
review_path=Path('D:/agentsync-debug/astra-codex-version-review.json')
review=json.loads(review_path.read_text(encoding='utf-8'));assert not review.get('open_blockers')
assert all(item['status']=='resolved' for item in review['findings'])
for name,digest in review['reviewed_files_sha256'].items():assert r['source_manifest'][name]==digest
for name,digest in r['source_manifest'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show',sha+':'+name],cwd=repo)).hexdigest()==digest
 assert hashlib.sha256((out/'source'/name).read_bytes()).hexdigest()==digest
case_sets=[]
for name,summary in r['suites'].items():
 cases=list(ET.parse(out/(name+'.xml')).getroot().iter('testcase'))
 ids={c.get('classname')+'::'+c.get('name') for c in cases}
 assert len(ids)==len(cases)==summary['passed'] and not any(c.find(t)is not None for c in cases for t in ('failure','error','skipped'))
 assert hashlib.sha256((out/(name+'.xml')).read_bytes()).hexdigest()==summary['junit_sha256'];case_sets.append(ids)
 origins=json.loads((out/(name+'-origins.json')).read_text(encoding='utf-8'));assert len(origins)==63
 base=(out/'source/src').resolve() if name.startswith('source') else (out/(name+'-venv')).resolve()
 for module,record in origins.items():
  p=Path(record['path']).resolve();assert p.is_relative_to(base)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256']==r['runtime_modules'][module]
assert len(case_sets)==4 and all(s==case_sets[0] for s in case_sets)
old=list(ET.parse('D:/agentsync-debug/alpha23-linux-full-9s8fju3r/evidence/junit.xml').getroot().iter('testcase'))
old+=list(ET.parse('D:/agentsync-debug/alpha26-lifecycle-vcrr1usf/source314.xml').getroot().iter('testcase'))
classes={item.rsplit('::',1)[0] for item in case_sets[0]}
oldids={c.get('classname')+'::'+c.get('name') for c in old if c.get('classname') in classes}
assert oldids and oldids<=case_sets[0] and len(case_sets[0]-oldids)==8
for name,record in r['checks'].items():assert record['exit_code']==0 and hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()==record['log_sha256']
for name,digest in r['artifacts'].items():assert hashlib.sha256((out/'artifacts'/name).read_bytes()).hexdigest()==digest
matched=0
with tarfile.open(next((out/'artifacts').glob('*.tar.gz'))) as stream:
 for m in stream:
  name='/'.join(Path(m.name).parts[1:])
  if m.isfile() and name in r['source_manifest']:
   assert hashlib.sha256(stream.extractfile(m).read()).hexdigest()==r['source_manifest'][name];matched+=1
audit={'source_commit':sha,'git_files':len(r['source_manifest']),'sdist_matching_git_members':matched,'runtime_origins_each':63,'unique_cases_each':len(case_sets[0]),'retained_prior_cases':len(oldids),'new_cases':len(case_sets[0]-oldids),'root_independent_checks':'Actual Git/file bytes, JUnit identities/results, origins, logs and artifact hashes PASS','review':'Astra limited static version-guard review; M5/Release not accepted'}
(out/'root-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
members={}
preflight=Path('D:/agentsync-debug/codex-compat-preflight-1iugmsv9')
probes=json.loads((preflight/'result.json').read_text(encoding='utf-8'))
for label,details in probes['binaries'].items():
 for name,record in details['probes'].items():
  path=preflight/(label+'-'+name+'.log')
  assert record['exit_code']==0 and hashlib.sha256(path.read_bytes()).hexdigest()==record['log_sha256']
  members['readonly-cli/'+path.name]=path
members['readonly-cli/result.json']=preflight/'result.json'
plan=json.loads((out/'actual-desktop-plan.json').read_text(encoding='utf-8'))
assert plan['binary_sha256']==probes['binaries']['desktop']['binary_sha256']
assert plan['runtime_source_sha256']==r['source_manifest']['src/agentsync/adapters/codex_invocation.py']
assert plan['executes'] is False and plan['real_client_task']=='NOT RUN'
for p in (Path('D:/agentsync-debug/codex-readonly-feature-preflight.py'),Path('D:/agentsync-debug/verify-actual-desktop-plan.py')):
 members['drivers/'+p.name]=p
for p in out.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.xml','.py'}:members['evidence/'+p.name]=p
for p in (out/'artifacts').iterdir():members['artifacts/'+p.name]=p
for p in Path('D:/agentsync-debug/m6-codex-version-sol').iterdir():
 if p.is_file() and p.suffix in {'.log','.xml'}:members['development/'+p.name]=p
members['review/astra-codex-version-review.json']=review_path
for p in (Path(__file__),Path('D:/agentsync-debug/verify-alpha28-codex-version.py')):members['drivers/'+p.name]=p
manifest={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in members.items()}
archive=repo/'releases/0.3.0a28/checkpoints'/('local-'+sha[:7]+'.tar.gz');archive.parent.mkdir(parents=True,exist_ok=True);assert not archive.exists()
with tarfile.open(archive,'w:gz') as stream:
 for name,p in members.items():stream.add(p,arcname=name,recursive=False)
 raw=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);stream.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as stream:
 for name,record in manifest.items():
  raw=stream.extractfile(name).read();assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
summary={'schema':'agentsync.local-checkpoint.v1','version':'0.3.0a28','source_commit':sha,'scope':'M6 exact desktop Codex version admission; live tasks NOT RUN','suites':{n:{k:v for k,v in s.items() if k!='case_ids'} for n,s in r['suites'].items()},'identity':audit,'static':'Ruff/format/mypy63 PASS','independent_review':'Astra limited static design/source review; no open blockers; Work pending','artifacts':r['artifacts'],'archive':str(archive.relative_to(repo)).replace('\\','/'),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'manifest_members':len(manifest),'not_run':['full repository suite at this SHA','Linux/macOS at this SHA','real clients','autonomous relay','formal42 acceptance'],'release':'BLOCKED','failures_preserved':'Initial RED1 new-version rejection and six passing rejection cases retained; fixed before freeze. Factory tests use owned Python fixtures; actual Codex only version/help/read-only feature listing and real-binary plan preparation.'}
(repo/'docs/acceptance/evidence/alpha28-local-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
