"""Prepare against the probed real binary; never invoke the factory or client task."""
import hashlib,json,sys,tempfile
from pathlib import Path
source=Path(sys.argv[1]);destination=Path(sys.argv[2]);sys.path.insert(0,str(source/'src'))
from agentsync.adapters.base import AdapterTask
from agentsync.adapters.codex_invocation import CodexHostProfile,prepare_invocation
binary=Path('C:/Program Files/WindowsApps/OpenAI.Codex_26.1029.7803.0_x64__2p2nqsd0c76g0/app/resources/codex.exe')
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest=='925c7d0665ffa49b0dcf748e034a805a04da984164ac92301432073b47789b99'
with tempfile.TemporaryDirectory(prefix='codex-plan-only-',dir='D:/agentsync-debug') as child:
 profile=CodexHostProfile('compat-project','compat-session',binary,Path(child),digest,expected_cli_version='0.166.0-alpha.6')
 plan=prepare_invocation(profile,AdapterTask('compat-project','compat-session','compat-task','compat-request',instruction='Compatibility preparation only; do not execute.'),environment={})
 assert plan.expected_cli_version=='0.166.0-alpha.6' and plan.binary_sha256==digest
 assert not any((plan.executes,plan.version_verified,plan.auth_verified,plan.billing_verified,plan.real_client_verified,plan.sandbox_verified))
 assert plan.child_env()=={} and '--strict-config' in plan.argv and '--ignore-user-config' in plan.argv
 result={'scope':'Real pinned desktop binary plan preparation only','observed_cli_version':'0.166.0-alpha.6','binary_sha256':digest,'fixed_argv':plan.argv,'explicit_environment_empty':True,'executes':False,'real_client_task':'NOT RUN','auth_verified':False,'billing_verified':False,'version_verified_in_plan':False,'sandbox_verified':False,'runtime_source_sha256':hashlib.sha256((source/'src/agentsync/adapters/codex_invocation.py').read_bytes()).hexdigest()}
 destination.write_text(json.dumps(result,indent=2),encoding='utf-8')
 print('Actual desktop binary prepared; no process/model task started.')
