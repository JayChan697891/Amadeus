"""Read CLI version/help/feature listing only; never pass a model prompt or login command."""
import hashlib,json,os,subprocess,tempfile
from pathlib import Path
out=Path(tempfile.mkdtemp(prefix='codex-compat-preflight-',dir='D:/agentsync-debug'))
home=out/'home';home.mkdir();(home/'codex').mkdir();(home/'appdata').mkdir();(home/'local').mkdir()
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','PATH','PATHEXT','COMSPEC'}}
env.update(CODEX_HOME=str(home/'codex'),HOME=str(home),USERPROFILE=str(home),APPDATA=str(home/'appdata'),LOCALAPPDATA=str(home/'local'),TEMP=str(out),TMP=str(out))
bins={
 'npm':Path('C:/Users/JayChan/AppData/Roaming/npm/node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/bin/codex.exe'),
 'desktop':Path('C:/Program Files/WindowsApps/OpenAI.Codex_26.1029.7803.0_x64__2p2nqsd0c76g0/app/resources/codex.exe'),
}
r={'scope':'version/help/read-only feature listing only; no model/login/config changes','real_client_task':'NOT RUN','empty_disposable_home':True,'documentation':'https://learn.chatgpt.com/docs/non-interactive-mode','binaries':{}}
for label,path in bins.items():
 item={'binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'probes':{}}
 for name,args in [('version',['--version']),('exec-help',['exec','--help']),('features',['features','list'])]:
  p=subprocess.run([str(path),*args],cwd=out,env=env,capture_output=True,timeout=15)
  raw=p.stdout+p.stderr; (out/(label+'-'+name+'.log')).write_bytes(raw)
  item['probes'][name]={'exit_code':p.returncode,'log_sha256':hashlib.sha256(raw).hexdigest()}
  if name=='version':item['version_output']=raw.decode('utf-8',errors='replace').strip()
  elif name=='exec-help':
   text=raw.decode('utf-8',errors='replace');item['exec_flags_present']={f:f in text for f in ['--json','--sandbox','--ephemeral','--ignore-user-config','--strict-config']}
 r['binaries'][label]=item
(out/'result.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print(out);print(json.dumps(r,indent=2))
