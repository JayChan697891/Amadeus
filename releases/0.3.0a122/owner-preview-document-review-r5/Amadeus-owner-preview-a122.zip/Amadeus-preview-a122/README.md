# Amadeus a122 开发体验包

先体验：本地任务创建、持久化保存、进程重开后恢复、交接和不同身份评审。
默认演示使用模拟 Agent，不需要模型账号，也不会产生模型调用费用。
这是限定开发体验；正式 Release 仍为 BLOCKED。

## Windows quick start

需要 Python 3.12。解压后，在本文件所在目录打开 PowerShell，依次运行：

```powershell
py -3.12 -m venv .venv-amadeus
& .\.venv-amadeus\Scripts\python.exe -m pip install -c .\constraints-windows312.txt .\agentsync_local-0.3.0a122-py3-none-any.whl
& .\.venv-amadeus\Scripts\amadeus.exe --data-dir "$PWD\local-data\trial-01" demo --durable
```

安装可能下载运行依赖；演示本身无需联网。无需激活环境或修改执行策略。
随包约束固定到已测试 Windows 3.12 环境的依赖版本，不安装开发测试工具。
这些约束不是跨平台通用锁文件，也不代表其他 Python 版本已经验收。
请选择尚不存在的环境和数据目录。预期结果包括 `ok: true`、已接受的交接、
`simulation_only: true` 与 `verification: unverified`。模拟评审不是独立执行验证。
保留数据目录以便检查记录；再次演示使用新目录，例如 `trial-02`。

Linux 可使用对应 Python 虚拟环境和 `bin/amadeus` 运行同一演示；
冻结包已在 Windows 3.12、Linux 3.14 上验证，macOS 尚未实测。

## 真实 Agent 任务入口

[Linux 初始化、任务执行及恢复指南](docs/VERIFIED-TASK-EXAMPLE.md)和四个示例脚本
已随包附带。需要另行准备受支持的 Codex CLI、订阅登录及本地 Docker 镜像；
不会自动安装这些工具、复制账号凭据、启动模型或执行候选代码。
每个实际操作保留精确审批，候选只在独立隔离环境验证。
此前终端入口已完成一次逐项审批的真实双 Codex 验证；详情见当前指南。
本修订保留 r4 的限量读取入口，新增独立文档接受/拒绝示例，已做8项受影响的 Windows 本地 Core 检查。
没有新增模型调用、候选执行或 Linux 终端实验，不能扩大原有验收范围。
不同厂商客户端与 macOS 也未完成真实验收。

## 包内容与检查结果

wheel 是原始 a122/5232e9e 文件，未重建；初始化和恢复脚本保留原件；终端入口来自a4f17c3的限量读取修复。
manifest.json 保存来源和各文件摘要，SHA256SUMS 保存完整文件校验值。
包内不包含账号凭据、数据库、模型CLI、Docker镜像或第三方依赖安装目录。
本项目代码采用随附 MIT 许可；运行依赖保留各自许可，最终许可审查仍待完成。

冻结核心已完成 Windows/Linux 六套限定回归；新入口只做受影响检查，
该记录不等同完整发布矩阵。
本修订复用核心安装原件并加入已检查的入口修复，未重跑完整测试套件。
[当前证据与限制](https://github.com/JayChan697891/Amadeus/blob/5f7d75af15532b04e0fe5da3cc48a69e2531086b/docs/PROGRESS.md)。

## 高级：手工接受或拒绝 review.md

新增 `examples/review_relay_document.py`，用已有项目的 owner 隐藏输入创建新独立
reviewer，展示固定 context v1 文档及精确决定；输入计划 SHA 后才一次提交。
参数和命令见 [文档审核指南](docs/VERIFIED-TASK-EXAMPLE.md#accept-or-reject-the-returned-document)。
接受后任务 completed，拒绝后 pending；普通文档仍 unverified，不是代码验证。
这一步不调用模型或 Docker、不重跑 receiver，也不恢复失败模型的未保存进度。
