# Amadeus a122 开发体验包

先体验：本地任务创建、持久化保存、进程重开后恢复、交接和不同身份评审。
默认演示使用模拟 Agent，不需要模型账号，也不会产生模型调用费用。
这是限定开发体验；正式 Release 仍为 BLOCKED。

## Windows quick start

需要 Python 3.12。解压后，在本文件所在目录打开 PowerShell，依次运行：

```powershell
py -3.12 -m venv .venv-amadeus
& .\.venv-amadeus\Scripts\python.exe -m pip install .\agentsync_local-0.3.0a122-py3-none-any.whl
& .\.venv-amadeus\Scripts\amadeus.exe --data-dir "$PWD\local-data\trial-01" demo --durable
```

安装可能下载运行依赖；演示本身无需联网。无需激活环境或修改执行策略。
请选择尚不存在的环境和数据目录。预期结果包括 `ok: true`、已接受的交接、
`simulation_only: true` 与 `verification: unverified`。模拟评审不是独立执行验证。
保留数据目录以便检查记录；再次演示使用新目录，例如 `trial-02`。

Linux 可使用对应 Python 虚拟环境和 `bin/amadeus` 运行同一演示；
冻结包已在 Windows 3.12、Linux 3.14 上验证，macOS 尚未实测。

## 真实 Agent 任务入口

[Linux 初始化、任务执行及恢复指南](docs/VERIFIED-TASK-EXAMPLE.md)和三个示例脚本
已随包附带。需要另行准备受支持的 Codex CLI、订阅登录及本地 Docker 镜像；
不会自动安装这些工具、复制账号凭据、启动模型或执行候选代码。
每个实际操作保留精确审批，候选只在独立隔离环境验证。
最新入口修复后的完整真实实验尚待授权和执行，不能称为已验收通过。
不同厂商客户端与 macOS 也未完成真实验收。

## 包内容与检查结果

wheel 是原始 a122/5232e9e 文件，未重建；终端及初始化脚本来自已检查的7085ec0。
manifest.json 保存来源和各文件摘要，SHA256SUMS 保存完整文件校验值。
包内不包含账号凭据、数据库、模型CLI、Docker镜像或第三方依赖安装目录。
本项目代码采用随附 MIT 许可；运行依赖保留各自许可，最终许可审查仍待完成。

原 wheel/sdist 已完成四套限定完整安装回归；该记录不等同完整发布矩阵。
本体验包仅重新组合已有原件，未重跑完整测试套件。
[当前证据与限制](https://github.com/JayChan697891/Amadeus/blob/6dcad6f45530be72c220e0b9e402cc690a1d6c9d/docs/PROGRESS.md)。
