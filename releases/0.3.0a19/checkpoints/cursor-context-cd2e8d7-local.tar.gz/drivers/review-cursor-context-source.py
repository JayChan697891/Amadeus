import hashlib,json,os,subprocess,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path(r'F:\syuc\agentsync-execution-intent');out=Path(tempfile.mkdtemp(prefix='cursor-context-source-',dir=r'D:\agentsync-debug'))
env=os.environ.copy();env.update(PYTHONPATH=str(repo/'src'),PYTHONDONTWRITEBYTECODE='1',TEMP=str(out),TMP=str(out),RUFF_CACHE_DIR=str(out/'ruff'),MYPY_CACHE_DIR=str(out/'mypy'))
selected=sorted({str(p.relative_to(repo)).replace('\\','/') for p in (repo/'tests/unit').glob('test_*adapter*.py')})
selected += ['tests/unit/'+n for n in ['test_process_capture.py','test_adapter_run_manager.py','test_codex_invocation.py','test_claude_invocation.py','test_codex_process.py','test_codex_events.py','test_claude_events.py','test_cursor_events.py','test_acceptance_traceability.py']]
selected += sorted(str(p.relative_to(repo)).replace('\\','/') for p in (repo/'tests/integration').glob('test_*adapter*boundary.py'))
selected += ['tests/integration/test_codex_invocation_process.py']
selected += ['tests/unit/test_claude_process.py']
selected=list(dict.fromkeys(selected));assert all((repo/n).is_file() for n in selected)
r={'selectors':selected,'checks':{},'modules':{str(p.relative_to(repo/'src')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'src/agentsync').rglob('*.py')}}
def run(name,cmd,timeout=120):
 p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,timeout=timeout);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);r['checks'][name]={'exit_status':p.returncode};return p
for name,python in {'py314':r'D:\agentsync-debug\venv\Scripts\python.exe','py311':r'D:\agentsync-debug\alpha13-python311-1_06_4p9\venv\Scripts\python.exe'}.items():
 xml=out/(name+'.xml');run(name,[python,'-m','pytest','-q',*selected,'--junitxml',str(xml),'--basetemp',str(out/(name+'-tmp')),'-o','cache_dir='+str(out/'pytestcache')])
 cases=ET.parse(xml).getroot().findall('.//testcase');r['checks'][name].update(tests=len(cases),passed=sum(not any(c.find(t)is not None for t in ['failure','error','skipped'])for c in cases),failed=sum(c.find('failure')is not None for c in cases),errors=sum(c.find('error')is not None for c in cases),skipped=sum(c.find('skipped')is not None for c in cases),junit_sha256=hashlib.sha256(xml.read_bytes()).hexdigest())
python=r'D:\agentsync-debug\venv\Scripts\python.exe'
run('ruff',[python,'-m','ruff','check','.']);run('format',[python,'-m','ruff','format','--check','.']);run('mypy',[python,'-m','mypy']);run('diff',['git','diff','--check'])
r['source_unchanged']=all(hashlib.sha256((repo/'src'/n).read_bytes()).hexdigest()==h for n,h in r['modules'].items())
r['passed']=all(v['exit_status']==0 for v in r['checks'].values()) and r['source_unchanged']
(out/'result.json').write_text(json.dumps(r,indent=2));print(json.dumps({'evidence':str(out),'modules':len(r['modules']),**r['checks'],'passed':r['passed']}),flush=True)
raise SystemExit(0 if r['passed'] else 1)
