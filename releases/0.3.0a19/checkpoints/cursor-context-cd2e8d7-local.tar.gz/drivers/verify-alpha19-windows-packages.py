import hashlib,json,os,subprocess,tarfile,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path(r'F:\syuc\agentsync-execution-intent');out=Path(tempfile.mkdtemp(prefix='alpha19-windows-',dir=r'D:\agentsync-debug'))
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit=='cd2e8d75555e954b41c421f1dfeb3308032ba440' and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
archive=out/'source.tar';subprocess.run(['git','archive','--format=tar','--output',str(archive),commit],cwd=repo,check=True)
source=out/'source';source.mkdir();manifest={}
with tarfile.open(archive) as stream:
 for m in stream:
  p=Path(m.name);assert not p.is_absolute() and '..' not in p.parts;target=source/p;assert target.resolve().is_relative_to(source.resolve())
  if m.isdir():target.mkdir(parents=True,exist_ok=True);continue
  assert m.isfile();target.parent.mkdir(parents=True,exist_ok=True);data=stream.extractfile(m).read();target.write_bytes(data);manifest[m.name]=hashlib.sha256(data).hexdigest()
modules={n.removeprefix('src/'):h for n,h in manifest.items() if n.startswith('src/agentsync/') and n.endswith('.py')};assert len(modules)==59
binding=out/'binding.json';binding.write_text(json.dumps(modules))
wrapper=out/'installed_tests.py';wrapper.write_text('''if __name__ == '__main__':
 import hashlib,importlib,json,pathlib,sys
 sys.dont_write_bytecode=True
 expected=json.loads(pathlib.Path(sys.argv[1]).read_text());destination=pathlib.Path(sys.argv[2]);base=pathlib.Path(sys.prefix).resolve()
 def verify():
  result={}
  for relative,digest in expected.items():
   name=relative.removesuffix('.py').replace('/','.').removesuffix('.__init__');module=importlib.import_module(name);origin=pathlib.Path(module.__file__).resolve()
   assert origin.is_relative_to(base) and hashlib.sha256(origin.read_bytes()).hexdigest()==digest
   result[relative]={'path':str(origin),'sha256':digest}
  return result
 before=verify();import agentsync;assert agentsync.__version__=='0.3.0a19'
 import pytest
 code=pytest.main(sys.argv[3:]);after=verify();assert before==after
 destination.write_text(json.dumps(after,indent=2));raise SystemExit(code)
''')
selectors=['tests/unit/test_codex_process.py','tests/unit/test_codex_adapter.py','tests/unit/test_claude_adapter.py','tests/unit/test_cursor_adapter.py','tests/unit/test_process_capture.py','tests/unit/test_adapter_run_manager.py','tests/integration/test_adapter_manager_core_boundary.py']
selectors.append('tests/unit/test_claude_process.py')
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','PATH','COMSPEC','PATHEXT'}}
home=out/'home';home.mkdir();env.update(TEMP=str(out),TMP=str(out),HOME=str(home),USERPROFILE=str(home),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_CONFIG_FILE=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull)
py=r'D:\agentsync-debug\venv\Scripts\python.exe';cache=r'D:\agentsync-debug\evidence\windows-final-aac28a0\windows-wheelhouse'
r={'commit':commit,'version':'0.3.0a19','runtime':'WindowsPython3.14','runtime_modules':modules,'source_manifest':manifest,'selectors':selectors,'checks':{},'packages':{},'formal_release':'BLOCKED','real_clients':'NOT RUN'}
def save():(out/'result.json').write_text(json.dumps(r,indent=2))
def run(name,cmd,cwd=out,timeout=120):
 p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,timeout=timeout);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);r['checks'][name]={'exit_status':p.returncode};save();assert p.returncode==0,name;return p
print(out,flush=True);save()
run('build',[py,'-m','build','--wheel','--sdist','--no-isolation','--outdir',str(out/'artifacts'),str(source)])
r['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'artifacts').iterdir()};save()
for kind,artifact in [('wheel',next((out/'artifacts').glob('*.whl'))),('sdist',next((out/'artifacts').glob('*.tar.gz')))]:
 venv=out/(kind+'-venv');run(kind+'-venv',[py,'-m','venv',str(venv)]);python=venv/'Scripts/python.exe'
 run(kind+'-tools',[str(python),'-m','pip','install','--no-index','--no-cache-dir','--find-links',cache,'setuptools==82.0.1','wheel==0.46.3','pytest==9.1.1','pytest-asyncio==1.4.0'])
 run(kind+'-install',[str(python),'-m','pip','install','--no-index','--no-cache-dir','--no-build-isolation','--find-links',cache,str(artifact)])
 run(kind+'-pipcheck',[str(python),'-m','pip','check'])
 xml=out/(kind+'.xml');run(kind+'-tests',[str(python),'-I','-B',str(wrapper),str(binding),str(out/(kind+'-origins.json')),'-p','pytest_asyncio.plugin','-q',*selectors,'--junitxml',str(xml),'--basetemp',str(out/(kind+'-tmp')),'-o','cache_dir='+str(out/(kind+'-cache'))],cwd=source)
 cases=ET.parse(xml).getroot().findall('.//testcase');r['packages'][kind]={'tests':len(cases),'passed':sum(not any(c.find(t)is not None for t in ['failure','error','skipped'])for c in cases),'failed':sum(c.find('failure')is not None for c in cases),'errors':sum(c.find('error')is not None for c in cases),'skipped':sum(c.find('skipped')is not None for c in cases),'actual_imports':len(json.loads((out/(kind+'-origins.json')).read_text())),'junit_sha256':hashlib.sha256(xml.read_bytes()).hexdigest()};save()
 assert r['packages'][kind]['passed']==122 and r['packages'][kind]['tests']==122
r['source_unchanged']=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in manifest.items());assert r['source_unchanged']
r['passed']=True;save();print(json.dumps({'evidence':str(out),'commit':commit,'packages':r['packages'],'artifacts':r['artifacts'],'passed':True}),flush=True)
