if __name__ == '__main__':
 import hashlib,importlib,json,pathlib,sys
 source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(source/'src'));expected=json.loads((out/'binding.json').read_text())
 def audit():
  actual={}
  for name,h in expected.items():
   module=importlib.import_module(name.removesuffix('.py').replace('/','.').removesuffix('.__init__'));p=pathlib.Path(module.__file__).resolve()
   assert p==(source/'src'/name).resolve() and hashlib.sha256(p.read_bytes()).hexdigest()==h
   actual[name]={'path':str(p),'sha256':h}
  return actual
 before=audit();(out/'imports-before.json').write_text(json.dumps(before,indent=2))
 import pytest
 code=pytest.main(sys.argv[3:]);after=audit();assert before==after;(out/'imports-after.json').write_text(json.dumps(after,indent=2));raise SystemExit(code)
