set -eu
/root/jobs-env/bin/python - <<'READ_ONLY_AUTHORIZED_FIXTURES'
targets={'source': '/root/agentsync-alpha23-full-b50ba633353d4c5bbbae242ccf9293cd/test-temp', 'wheel': '/root/agentsync-installed-809454662c514c468b11f6aa59de1b3a/wheel-tmp', 'sdist': '/root/agentsync-installed-809454662c514c468b11f6aa59de1b3a/sdist-tmp'}

from pathlib import Path
import hashlib,json,sqlite3
result={}
for label,base in targets.items():
 root=Path(base).resolve();matches={p.resolve() for p in root.glob('test_actual_linux_docker*/service-state/agentsync.db')};assert len(matches)==1,(label,len(matches));path=matches.pop();assert path.is_relative_to(root)
 db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 proof_rows=[dict(r)for r in db.execute('SELECT * FROM task_verifications')];assert len(proof_rows)==1
 proof=proof_rows[0];job=dict(db.execute('SELECT * FROM candidate_verification_jobs WHERE id=?',(proof['job_id'],)).fetchone());binding=json.loads(job['metadata_json'])['binding'];authors=set(binding['creator_session_ids'])
 tasks=[dict(r)for r in db.execute('SELECT id,project_id,status,version,owner_session_id FROM tasks')]
 authors|={r['owner_session_id']for r in tasks if r['id']in {job['left_task_id'],job['right_task_id']}and r['owner_session_id']}
 identities={r['id']:dict(r)for r in db.execute('SELECT id,project_id,agent_id FROM sessions')}
 assert proof['reviewer_agent_id']==identities[proof['reviewer_session_id']]['agent_id']and all(identities[s]['agent_id']!=proof['reviewer_agent_id']for s in authors)
 review=[dict(r)for r in db.execute('SELECT * FROM reviews')];execution=dict(db.execute('SELECT * FROM candidate_executions WHERE id=?',(proof['execution_id'],)).fetchone());execution.pop('token_hash')
 result[label]={'fixture_database_readonly':str(path),'proofs':proof_rows,'job':job,'tasks':tasks,'reviews':review,'author_sessions':[identities[s]for s in sorted(authors)],'reviewer_session':identities[proof['reviewer_session_id']],'stored_execution':execution,'owner_authorized_independent_reviewer':True,'formal_release':'BLOCKED','real_clients':'NOT RUN'};db.close()
print(json.dumps(result,indent=2))

READ_ONLY_AUTHORIZED_FIXTURES
