from pathlib import Path
import hashlib,json,os,subprocess,tarfile,tempfile,sys,xml.etree.ElementTree as ET
repo=Path('F:/syuc/agentsync-execution-intent')
out=Path(tempfile.mkdtemp(prefix='alpha23-windows-selected-',dir='D:/agentsync-debug'))
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
archive=out/'source.tar';subprocess.run(['git','archive','--format=tar','--output',str(archive),commit],cwd=repo,check=True)
source=out/'source';source.mkdir();manifest={}
with tarfile.open(archive) as stream:
 for m in stream:
  target=source/m.name;assert target.resolve().is_relative_to(source.resolve())
  if m.isdir():target.mkdir(parents=True,exist_ok=True);continue
  assert m.isfile();target.parent.mkdir(parents=True,exist_ok=True);data=stream.extractfile(m).read();target.write_bytes(data);manifest[m.name]=hashlib.sha256(data).hexdigest()
modules={n.removeprefix('src/'):h for n,h in manifest.items() if n.startswith('src/agentsync/') and n.endswith('.py')}
(out/'binding.json').write_text(json.dumps(modules))
wrapper=out/'run.py';wrapper.write_text('''if __name__ == '__main__':
 import hashlib,importlib,json,pathlib,sys
 source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);sys.path.insert(0,str(source/'src'));expected=json.loads((out/'binding.json').read_text())
 def audit():
  actual={}
  for name,h in expected.items():
   module=importlib.import_module(name.removesuffix('.py').replace('/','.').removesuffix('.__init__'));p=pathlib.Path(module.__file__).resolve()
   assert p==(source/'src'/name).resolve() and hashlib.sha256(p.read_bytes()).hexdigest()==h
   actual[name]={'path':str(p),'sha256':h}
  return actual
 before=audit();(out/'imports-before.json').write_text(json.dumps(before,indent=2))
 import pytest
 code=pytest.main(sys.argv[3:]);after=audit();assert before==after;(out/'imports-after.json').write_text(json.dumps(after,indent=2));raise SystemExit(code)
''')
py='D:/agentsync-debug/alpha13-python311-1_06_4p9/venv/Scripts/python.exe'
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','PATH','COMSPEC','PATHEXT','APPDATA','LOCALAPPDATA'}}
(out/'home').mkdir();env.update(TEMP=str(out),TMP=str(out),HOME=str(out/'home'),USERPROFILE=str(out/'home'),PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull)
args=['-p','pytest_asyncio.plugin','-v',*sys.argv[1:],'--basetemp',str(out/'tmp'),'-o','cache_dir='+str(out/'cache'),'--junitxml',str(out/'junit.xml')]
r={'commit':commit,'scope':'Windows Python3.11 selected source tests only','runtime':py,'manifest':manifest,'runtime_modules':modules,'selectors':sys.argv[1:],'formal_release':'BLOCKED','real_clients':'NOT RUN'}
(out/'result.json').write_text(json.dumps(r,indent=2));print(out,flush=True)
try:
 p=subprocess.run([py,'-B',str(wrapper),str(source),str(out),*args],cwd=source,env=env,capture_output=True,timeout=420)
 (out/'pytest.log').write_bytes(p.stdout+p.stderr);r['exit_code']=p.returncode
except subprocess.TimeoutExpired as e:
 (out/'pytest.log').write_bytes((e.stdout or b'')+(e.stderr or b''));r['status']='TIMEOUT / NOT COMPLETED';r['exit_code']=None
r['source_unchanged']=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
if (out/'junit.xml').exists():
 cases=list(ET.parse(out/'junit.xml').getroot().iter('testcase'));r['junit']={'tests':len(cases),'failed':sum(c.find('failure')is not None for c in cases),'errors':sum(c.find('error')is not None for c in cases),'skipped':sum(c.find('skipped')is not None for c in cases)};r['junit']['passed']=len(cases)-sum(r['junit'][k]for k in ('failed','errors','skipped'))
r['passed']=r['exit_code']==0 and r['source_unchanged'];(out/'result.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k not in ('manifest','runtime_modules')}));raise SystemExit(0 if r['passed']else 1)
