from pathlib import Path
import hashlib,json,os,subprocess
r=Path('D:/agentsync-debug/b23complete-b00mmdfm');source=r/'source';py='D:/agentsync-debug/venv/Scripts/python.exe'
env={k:v for k,v in os.environ.items()if k.upper()in {'SYSTEMROOT','WINDIR','COMSPEC','PATH','PATHEXT'}}
env.update(TEMP=str(r),TMP=str(r),PYTHONDONTWRITEBYTECODE='1',MYPY_CACHE_DIR=str(r/'mypy-cache'),RUFF_CACHE_DIR=str(r/'ruff-cache'))
result={'commit':json.loads((r/'result.json').read_text())['commit'],'checks':[]}
for name,args in [('ruff',['ruff','check','.']),('format',['ruff','format','--check','.']),('mypy',['mypy','src/agentsync'])]:
 p=subprocess.run([py,'-m',*args],cwd=source,env=env,capture_output=True,timeout=90);log=r/(name+'-frozen.log');log.write_bytes(p.stdout+p.stderr);result['checks'].append({'name':name,'exit_code':p.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});print(name,p.returncode,flush=True)
manifest=json.loads((r/'result.json').read_text())['source_manifest'];result['source_unchanged']=all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in manifest.items());result['passed']=result['source_unchanged']and all(c['exit_code']==0 for c in result['checks']);(r/'static-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));raise SystemExit(0 if result['passed']else 1)
