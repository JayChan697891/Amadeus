from pathlib import Path
import json,subprocess,sys
source=Path(sys.argv[1]);installed=Path(sys.argv[2]);read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sguest=read(source/'config.json')['guest'];iguest=read(installed/'config.json')['guest'];targets={'source':sguest+'/test-temp','wheel':iguest+'/wheel-tmp','sdist':iguest+'/sdist-tmp'}
body=r'''
from pathlib import Path
import hashlib,json,sqlite3
result={}
for label,base in targets.items():
 root=Path(base).resolve();matches={p.resolve() for p in root.glob('test_actual_linux_docker*/service-state/agentsync.db')};assert len(matches)==1,(label,len(matches));path=matches.pop();assert path.is_relative_to(root)
 db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 proof_rows=[dict(r)for r in db.execute('SELECT * FROM task_verifications')];assert len(proof_rows)==1
 proof=proof_rows[0];job=dict(db.execute('SELECT * FROM candidate_verification_jobs WHERE id=?',(proof['job_id'],)).fetchone());binding=json.loads(job['metadata_json'])['binding'];authors=set(binding['creator_session_ids'])
 tasks=[dict(r)for r in db.execute('SELECT id,project_id,status,version,owner_session_id FROM tasks')]
 authors|={r['owner_session_id']for r in tasks if r['id']in {job['left_task_id'],job['right_task_id']}and r['owner_session_id']}
 identities={r['id']:dict(r)for r in db.execute('SELECT id,project_id,agent_id FROM sessions')}
 assert proof['reviewer_agent_id']==identities[proof['reviewer_session_id']]['agent_id']and all(identities[s]['agent_id']!=proof['reviewer_agent_id']for s in authors)
 review=[dict(r)for r in db.execute('SELECT * FROM reviews')];execution=dict(db.execute('SELECT * FROM candidate_executions WHERE id=?',(proof['execution_id'],)).fetchone());execution.pop('token_hash')
 result[label]={'fixture_database_readonly':str(path),'proofs':proof_rows,'job':job,'tasks':tasks,'reviews':review,'author_sessions':[identities[s]for s in sorted(authors)],'reviewer_session':identities[proof['reviewer_session_id']],'stored_execution':execution,'owner_authorized_independent_reviewer':True,'formal_release':'BLOCKED','real_clients':'NOT RUN'};db.close()
print(json.dumps(result,indent=2))
'''
p=source/'root-fixture-observation.sh';p.write_text("set -eu\n/root/jobs-env/bin/python - <<'READ_ONLY_AUTHORIZED_FIXTURES'\ntargets="+repr(targets)+'\n'+body+'\nREAD_ONLY_AUTHORIZED_FIXTURES\n',encoding='utf-8',newline='\n')
r=subprocess.run(['D:/agentsync-debug/venv/Scripts/python.exe','-B','F:/syuc/agentsync-execution-intent/tools/local_vm_exec.py','--script',str(p),'--timeout','30','--log',str(source/'root-fixture-observation.json')],capture_output=True,timeout=50);(source/'root-fixture-transport.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0;r=read(source/'root-fixture-observation.json');assert set(r)=={'source','wheel','sdist'};print('Read-only actual fixture identity observations saved for three environments')
