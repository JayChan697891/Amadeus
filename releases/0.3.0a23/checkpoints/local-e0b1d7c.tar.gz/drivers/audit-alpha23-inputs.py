from pathlib import Path
import hashlib,io,json,subprocess,tarfile,zipfile
repo=Path('F:/syuc/agentsync-execution-intent');build=Path('D:/agentsync-debug/b23complete-b00mmdfm');source=Path('D:/agentsync-debug/alpha23-linux-full-9s8fju3r');win=Path('D:/agentsync-debug/alpha23-windows-selected-t29ah2ik');read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
b=read(build/'result.json');c=read(source/'config.json');w=read(win/'result.json');commit=c['commit'];assert b['commit']==w['commit']==commit and b['source_manifest']==c['manifest']==w['manifest']
names=sorted(c['manifest']);raw=subprocess.run(['git','cat-file','--batch'],cwd=repo,capture_output=True,check=True,input=('\n'.join(commit+':'+n for n in names)+'\n').encode()).stdout;stream=io.BytesIO(raw);inputs={}
for n in names:
 header=stream.readline().decode().split();assert header[1]=='blob';data=stream.read(int(header[2]));assert stream.read(1)==b'\n'and sha(data)==c['manifest'][n]
 if n.startswith(('src/','tests/','tools/'))or n=='pyproject.toml':inputs[n]=data
modules={n.removeprefix('src/'):sha(v)for n,v in inputs.items()if n.startswith('src/agentsync/')and n.endswith('.py')};assert len(modules)==63 and b['runtime_modules']==modules
with zipfile.ZipFile(next((build/'artifacts').glob('*.whl')))as z:assert all(sha(z.read(n))==h for n,h in modules.items())
with tarfile.open(next((build/'artifacts').glob('*.tar.gz')))as z:members={m.name.split('/',1)[1]:z.extractfile(m).read()for m in z if m.isfile()and '/'in m.name}
assert set(inputs)<=set(members)and all(members[n]==v for n,v in inputs.items())
for n,h in b['artifacts'].items():assert sha((build/'artifacts'/n).read_bytes())==h
before=read(win/'imports-before.json');after=read(win/'imports-after.json');assert before==after and set(after)==set(modules)and all(v['sha256']==modules[n]and Path(v['path']).resolve()==(win/'source/src'/n).resolve()for n,v in after.items());assert w['passed']and w['junit']=={'tests':6,'failed':0,'errors':0,'skipped':0,'passed':6}
static=read(build/'static-result.json');assert static['commit']==commit and static['passed']
result={'commit':commit,'git_inputs':len(names),'sdist_inputs':len(inputs),'runtime_modules':len(modules),'artifacts':b['artifacts'],'windows311':w['junit'],'frozen_static_pass':True,'linux_source':'RUNNING','installed_linux':'NOT RUN','release_gate':'BLOCKED'}
(build/'root-preaudit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
