from pathlib import Path
import hashlib,json,re,sys,xml.etree.ElementTree as ET
source=Path('D:/agentsync-debug/alpha23-linux-full-9s8fju3r');installed=Path(sys.argv[1]);build=Path('D:/agentsync-debug/b23complete-b00mmdfm');read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
c=read(source/'config.json');s=read(source/'evidence/result.json');p=read(installed/'config.json');i=read(installed/'evidence/result.json');pre=read(build/'root-preaudit.json');assert s['commit']==p['commit']==i['commit']==pre['commit']==c['commit'];assert s['passed']and s['source_unchanged']and i['status']=='AFFECTED_INSTALLED_MODULE_PASS'
def cases(path):
 rows=list(ET.parse(path).getroot().iter('testcase'));ids={(r.get('classname'),r.get('name'))for r in rows};assert len(rows)==len(ids)and not any(r.find(k)is not None for r in rows for k in ('failure','error'));skips=[{'class':r.get('classname'),'name':r.get('name'),'reason':r.find('skipped').get('message')}for r in rows if r.find('skipped')is not None];return ids,skips
ids,skips=cases(source/'evidence/junit.xml');assert len(ids)==1899 and len(skips)==4
old,_=cases(Path('D:/agentsync-debug/alpha22-linux-full-jeqlqg_1/evidence/junit.xml'));old={(cl,n.replace('future_schema14','future_schema15'))for cl,n in old};assert len(old)==1868 and old<=ids and len(ids-old)==31
modules=pre['runtime_modules'];expected=p['modules'];assert len(expected)==modules==63 and read(source/'evidence/imports-before.json')==read(source/'evidence/imports-after.json')==expected
selected={x for x in ids if x[0].endswith(('test_candidate_execution','test_verified_task_completion'))};assert len(selected)==64
for kind in ('wheel','sdist'):
 current,platformskips=cases(installed/'evidence'/(kind+'-junit.xml'));assert current==selected and len(platformskips)==1
 origins=read(installed/'evidence'/(kind+'-origins.json'));assert set(origins)==set(expected)
 assert all(v['sha256']==expected[n]and v['path'].startswith(p['guest']+'/'+kind+'/lib/')and '/site-packages/agentsync/'in v['path']for n,v in origins.items())
 assert read(installed/'evidence'/(kind+'-direct-url.json'))['archive_info']['hashes']['sha256']==p['artifacts'][p[kind]]==pre['artifacts'][p[kind]]
actual=read(source/'root-fixture-observation.json');observations=[]
for kind,path in [('source',source/'evidence/task-completion-evidence/actual-verified-task-completion.json'),('wheel',installed/'evidence/wheel-task-completion/actual-verified-task-completion.json'),('sdist',installed/'evidence/sdist-task-completion/actual-verified-task-completion.json')]:
 v=read(path);db=actual[kind];proof=v['receipt']['verification'];stored=db['proofs'][0];execution=db['stored_execution'];ep=json.loads(execution['proof_json']);result=json.loads(execution['result_json']);job=db['job'];metadata=json.loads(job['metadata_json']);review=db['reviews'][0]
 assert v['real_docker']is True and v['real_clients']=='NOT RUN'and v['current']['task_verification']=='verified'and v['current']['verification']==proof
 assert v['stored_verifications']==db['proofs']and json.loads(stored['proof_json'])==proof and sha(stored['proof_json'].encode())==stored['proof_sha256']
 assert sha(job['metadata_json'].encode())==job['metadata_sha256']and job['left_task_version']==job['right_task_version']==proof['review_version']==3 and proof['completed_version']==4
 assert proof['execution_id']==execution['id']==result['execution_id']and proof['job_id']==job['id']==execution['job_id']and execution['phase']=='finished'and execution['assessment']=='passed'
 assert proof['candidate_sha']==job['candidate_sha']==ep['candidate_sha']==result['commit_sha']and proof['candidate_sha']!=job['base_sha']
 for key in ('tree_sha','input_sha256','source_sha256','profile_sha256'):
  assert proof[key]==job[key]==ep[key]==result[key]
 literal=b"import json,sys\nfor line in sys.stdin:\n json.loads(line)\n print(json.dumps('candidate'))\n";assert proof['source_sha256']==sha(literal)
 assert proof['image_id']==result['image_sha256']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
 assert proof['result_sha256']==execution['result_sha256']==sha(execution['result_json'].encode())and proof['execution_proof_sha256']==execution['proof_sha256']==sha(execution['proof_json'].encode())
 assert result['cleanup_confirmed']is True and result['status']=='passed'and result['errors']==[]and result['provenance']=='docker_black_box'and all(x is True for x in result['isolation']['checks'].values())
 assert proof['reviewer_agent_id']==review['reviewer_agent_id']==v['current']['latest_review']['reviewer_agent_id']==db['reviewer_session']['agent_id']and all(a['agent_id']!=proof['reviewer_agent_id']for a in db['author_sessions'])
 assert proof['reviewer_session_id']==review['reviewer_session_id']and review['accept']==1 and review['version']==4
 assert v['fixture_safety_cleanup']['absence_observed']is True and v['execution']['execution']['task_verification']=='unverified'
 observations.append({'environment':kind,'execution_id':execution['id'],'verification_id':proof['id'],'container_id':execution['container_id'],'independent_reviewer':True,'current_task_version':4,'bound_pair_versions':[3,3]})
containers=set()
def visit(v):
 if isinstance(v,dict):
  for key,value in v.items():
   if key=='container_id'and isinstance(value,str)and re.fullmatch('[0-9a-f]{64}',value):containers.add(value)
   visit(value)
 elif isinstance(v,list):
  for value in v:visit(value)
for base in (source/'evidence',installed/'evidence'):
 for path in base.rglob('*.json'):
  if any(x in str(path.parent)for x in ('docker','owner','reconciliation','candidate','task-completion')):visit(read(path))
assert len(containers)>=18 and all(x['container_id']in containers for x in observations)
record=pre|{'source':s['junit'],'source_skips':skips,'retained_prior_full_cases':1868,'new_since_prior_full':31,'new_B4_cases':27,'installed_each':{'tests':64,'passed':63,'skipped':1,'failed':0,'errors':0},'actual_B4_observations':observations,'container_ids':sorted(containers),'linux_source':'PASS','installed_linux':'AFFECTED_MODULES_PASS','release_gate':'BLOCKED','real_clients':'NOT RUN','formal_requirements':'42not_run; no formal requirement upgraded'}
(source/'root-audit.json').write_text(json.dumps(record,indent=2));script="set -eu\n/root/jobs-env/bin/python - <<'EXACT_RECORDED_CONTAINER_POSTCHECK'\nimport json,subprocess\nids="+repr(sorted(containers))+"\np=subprocess.run(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,check=True,timeout=15)\nremaining=sorted(set(p.stdout.splitlines())&set(ids));print(json.dumps({'recorded_full_ids':len(ids),'remaining_recorded_ids':remaining,'all_recorded_ids_absent':not remaining}));assert not remaining\nEXACT_RECORDED_CONTAINER_POSTCHECK\n";(source/'postcheck.sh').write_text(script,encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in record.items()if k not in ('container_ids','actual_B4_observations')}))
