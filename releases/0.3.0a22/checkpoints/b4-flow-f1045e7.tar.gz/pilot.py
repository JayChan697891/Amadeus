import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from unittest.mock import patch
ROOT=Path(r'D:\agentsync-debug\b4-flow-pilot')
REPO=Path(r'F:\syuc\agentsync-execution-intent')
sys.path[:0]=[str(REPO/'src'),str(REPO/'tests'/'integration'),str(REPO/'tests')]
from test_candidate_export import prepared as prepared_fixture
from test_m4b_workspaces import world as world_fixture,call
from test_candidate_execution import synthetic_backend
from test_candidate_jobs import enqueue,owner,profile
from agentsync.storage.database import connect
from agentsync.errors import AgentSyncError
from agentsync.verification import candidate_executor as module
from agentsync.verification.candidate import OwnerCandidateExporter
from agentsync.verification.candidate_claims import OwnerCandidateClaims
from agentsync.verification.candidate_intents import OwnerCandidateExecutionIntents
from agentsync.verification.candidate_executor import OwnerCandidateExecutor

result={'status':'RUNNING','scope':'B4 reachability pilot ONLY; not implementation or acceptance',
 'backend':'MOCK.synthetic_backend','real_docker':False,'real_clients':'NOT RUN',
 'backend_calls':0,'steps':[],'code_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()}
files=['src/agentsync/verification/candidate_executor.py','src/agentsync/verification/binding.py',
 'src/agentsync/verification/candidate_jobs.py','tests/integration/test_candidate_execution.py']
def hashes():return {n:hashlib.sha256((REPO/n).read_bytes()).hexdigest() for n in files}
def step(name,**values):
 result['steps'].append({'step':name,**values})
 (ROOT/'result.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result['steps'][-1]),flush=True)
def task_view(task):return {'status':task['status'],'version':task['version']}
def job_versions(job):
 with connect(core.db_path) as db:
  return list(db.execute("SELECT left_task_version,right_task_version FROM candidate_verification_jobs WHERE id=?",(job['id'],)).fetchone())
def reserve(job):
 claim=OwnerCandidateClaims(core).claim_once(**auth,job_id=job['id'],expected_version=1,profile=policy)
 intent=OwnerCandidateExecutionIntents(core).prepare_once(**auth,job_id=job['id'],expected_version=2,profile=policy)
 return dict(**auth,job_id=job['id'],intent_id=intent['intent']['id'],expected_job_version=2,
             expected_intent_revision=1,profile=policy)
def backend(source,**options):
 result['backend_calls']+=1
 return synthetic_backend(source,**options)
def versions(binding):return [binding.left_task_version,binding.right_task_version]
def main():
 global core,auth,policy
 before=hashes()
 try:
  fixture=ROOT/'f2';fixture.mkdir()
  world=world_fixture.__wrapped__(fixture)
  prepared=prepared_fixture.__wrapped__(world)
  core,_,left,right,_=prepared
  auth=owner(prepared);policy=profile();executor=OwnerCandidateExecutor(core)
  actors=world[2];leases=[]
  for actor,tree in zip(actors,(left,right)):
   current=next(t for t in call(core,actor,'list_tasks')['tasks'] if t['id']==tree['task_id'])
   leases.append(call(core,actor,'claim_task',task_id=tree['task_id'],expected_version=current['version'],request_id='pilot-claim'))
  old=enqueue(prepared,request_id='pilot-before-review');old_args=reserve(old)
  step('enqueue_and_reserve_before_review',tasks=[task_view(t) for t in leases],job_versions=job_versions(old))
  review=[]
  for actor,tree,lease in zip(actors,(left,right),leases):
   review.append(call(core,actor,'update_task',task_id=tree['task_id'],expected_version=lease['version'],lease_token=lease['lease_token'],status='review',result='Pilot submission only',request_id='pilot-submit'))
  step('submit_both_via_Core_update_task',tasks=[task_view(t) for t in review])
  with patch.object(module,'verify_python_json_lines',backend):
   try:executor.execute_once(**old_args)
   except AgentSyncError as error:old_error=error.code
   else:raise AssertionError('Old task binding unexpectedly executed')
   step('old_job_fresh_binding_rejected',error_code=old_error,backend_calls=result['backend_calls'])
   assert old_error=='stale_candidate_input' and result['backend_calls']==0
   fresh=enqueue(prepared,request_id='pilot-at-review');fresh_args=reserve(fresh)
   stored=job_versions(fresh)
   actual=[t['version'] for t in review]
   step('reenqueue_same_candidate_new_request',job_versions=stored,current_review_versions=actual,same_candidate=fresh['candidate_sha']==old['candidate_sha'],version_minus_one=[v-1 for v in actual])
   assert stored==actual and stored!=[v-1 for v in actual]
   simulated=executor.execute_once(**fresh_args)
   step('MOCK_only_execution',assessment=simulated['execution_assessment'],phase=simulated['execution']['phase'],backend_calls=result['backend_calls'],task_verification=simulated['execution']['task_verification'])
   assert simulated['execution_assessment']=='passed' and result['backend_calls']==1
  completed=call(core,actors[1],'review_task',task_id=left['task_id'],expected_version=review[0]['version'],accept=True,evidence='Textual review in local reachability pilot; MOCK backend is not verified evidence',request_id='pilot-text-review-left')
  binding=OwnerCandidateExporter(core).export(**prepared[1]).binding
  remaining=next(t for t in call(core,actors[0],'list_tasks')['tasks'] if t['id']==right['task_id'])
  step('textual_review_completes_left_only',left=task_view(completed),right=task_view(remaining),old_job_versions=stored,current_binding_versions=versions(binding),pair_binding_stale=versions(binding)!=stored,executor_replay_also_permanently_fenced=True)
  assert completed['status']=='completed' and remaining['status']=='review' and versions(binding)!=stored
  result.update(status='PASS',design_impact='A job binds both current task versions. Textual completion of one side advances its version and makes that pair binding stale for the other side. The existing execution is also permanently fenced; no B4 verified wrapper or completion was implemented.')
 except BaseException as error:
  result.update(status='FAILED',error_type=type(error).__name__,error_code=getattr(error,'code',None),error_key=error.args[0] if isinstance(error,KeyError) and error.args and error.args[0] in {'left_task_version','right_task_version','task_id','tasks','execution','phase','task_verification'} else None)
 finally:
  result['source_hashes_before']=before;result['source_hashes_after']=hashes()
  result['source_unchanged']=before==result['source_hashes_after']
  result['command']=[sys.executable,str(ROOT/'pilot.py')];result['runtime']=sys.version
  result['first_run_retained']='first-pilot.py / first-result.json / first-pilot.log; KeyError occurred before first step; no actual error key was logged'
  result['git_status_after']=subprocess.check_output(['git','status','--short'],cwd=REPO,text=True)
  (ROOT/'result.json').write_text(json.dumps(result,indent=2))
  print(json.dumps({'status':result['status'],'backend_calls':result['backend_calls'],'source_unchanged':result['source_unchanged']}),flush=True)
 return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
