import hashlib, io, json, re, subprocess, tarfile, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo=Path('F:/syuc/agentsync-execution-intent')
source=Path('D:/agentsync-debug/alpha22-linux-lifecycle-source-z8u834zr')
installed=Path('D:/agentsync-debug/alpha22-lifecycle-installed-d6yimu2l')
build=Path('D:/agentsync-debug/b22life-cawp6xrc')
focus=Path('D:/agentsync-debug/alpha22-linux-lifecycle-focus-rwopu91l')
commit='bda27722ace70eec4f2ea59696c3301763828fd6'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()

def cases(p,n,skip):
    rows=list(ET.parse(p).getroot().iter('testcase'));ids={(r.get('classname'),r.get('name'))for r in rows}
    assert len(ids)==len(rows)==n
    assert not any(r.find(k)is not None for r in rows for k in ('failure','error'))
    reasons=[{'case':r.get('name'),'reason':r.find('skipped').get('message')}for r in rows if r.find('skipped')is not None]
    assert len(reasons)==skip
    return ids,reasons

c=read(source/'config.json');s=read(source/'evidence/result.json')
p=read(installed/'config.json');r=read(installed/'evidence/result.json');b=read(build/'result.json')
assert c['commit']==s['commit']==p['commit']==r['commit']==b['commit']==commit
assert s['passed'] is True and r['status']=='AFFECTED_INSTALLED_MODULE_PASS'
ids,skips=cases(source/'evidence/junit.xml',37,1)
old=ET.parse('D:/agentsync-debug/alpha22-linux-full-jeqlqg_1/evidence/junit.xml').getroot().iter('testcase')
old_ids={(x.get('classname'),x.get('name'))for x in old if x.get('classname').endswith('test_candidate_execution')}
assert len(old_ids)==33 and old_ids<=ids and len(ids-old_ids)==4
assert not subprocess.check_output(['git','diff','--name-only','437d306',commit,'--','src','tools','pyproject.toml'],cwd=repo,text=True).strip()

names=sorted(c['manifest']);stream=io.BytesIO(subprocess.run(['git','cat-file','--batch'],cwd=repo,capture_output=True,check=True,input=('\n'.join(commit+':'+n for n in names)+'\n').encode()).stdout)
git={}
for name in names:
    h=stream.readline().decode().split();assert h[1]=='blob'
    data=stream.read(int(h[2]));assert stream.read(1)==b'\n' and sha(data)==c['manifest'][name]
    if name.startswith(('src/','tests/','tools/'))or name=='pyproject.toml':git[name]=data
modules={n.removeprefix('src/'):sha(v)for n,v in git.items()if n.startswith('src/agentsync/')and n.endswith('.py')}
assert len(names)==389 and len(modules)==62 and len(git)==178
assert read(source/'evidence/imports-before.json')==read(source/'evidence/imports-after.json')==modules
assert read(Path('D:/agentsync-debug/alpha22-linux-full-jeqlqg_1/evidence/imports-after.json'))==modules
assert b['source_manifest']==c['manifest'] and p['modules']==modules
for kind in ('wheel','sdist'):
    current,_=cases(installed/'evidence'/(kind+'-junit.xml'),37,1);assert current==ids
    origins=read(installed/'evidence'/(kind+'-origins.json'));assert set(origins)==set(modules)
    for name,v in origins.items():
        assert v['sha256']==modules[name] and v['path'].startswith(p['guest']+'/'+kind+'/lib/') and '/site-packages/agentsync/'in v['path']
    artifact=p[kind];data=(build/'artifacts'/artifact).read_bytes();assert sha(data)==p['artifacts'][artifact]
    assert read(installed/'evidence'/(kind+'-direct-url.json'))['archive_info']['hashes']['sha256']==sha(data)
with zipfile.ZipFile(build/'artifacts'/p['wheel'])as z:
    assert all(sha(z.read(n))==h for n,h in modules.items())
with tarfile.open(build/'artifacts'/p['sdist'])as z:
    members={m.name.split('/',1)[1]:z.extractfile(m).read()for m in z if m.isfile()and '/'in m.name}
assert set(git)<=set(members)and all(members[n]==v for n,v in git.items())

literal=b"import json,sys\nfor line in sys.stdin:\n json.loads(line)\n print(json.dumps('candidate'))\n"
expected={'actual-candidate-execution':literal,'actual-candidate-wrong-result':literal.replace(b"'candidate'",b"'wrong'"),'actual-candidate-timeout':b'import time\ntime.sleep(30)\n','actual-candidate-running-cancel':literal.replace(b'import json,sys',b'import json,sys,time').replace(b' print(json.dumps',b' time.sleep(3)\n print(json.dumps'),'actual-candidate-created-crash-cleanup':literal}
all_ids=set();observations=[]
for label,folder in [('source',source/'evidence/candidate-evidence'),('wheel',installed/'evidence/wheel-candidate'),('sdist',installed/'evidence/sdist-candidate'),('earlier-focused',focus/'evidence/candidate-evidence')]:
    paths=list(folder.rglob('*.json'));assert len(paths)==5 and {x.stem for x in paths}==set(expected)
    for path in paths:
        v=read(path);row=v['stored_execution'];proof=json.loads(row['proof_json']);view=v['current']['execution'];scenario=path.stem
        assert v['real_docker'] is True and v['real_clients']=='NOT RUN' and 'token_hash'not in row
        assert sha(row['proof_json'].encode())==row['proof_sha256']
        assert proof['source_sha256']==v['expected_source_sha256']==sha(expected[scenario])
        assert proof['candidate_sha']==v['historical_receipts'][0]['candidate_sha']!=v['base_sha']
        assert proof['verifier_sha256']==modules['agentsync/verification/docker.py']
        assert proof['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
        assert re.fullmatch('[a-f0-9]{64}',row['container_id'])and row['container_id']not in all_ids
        all_ids.add(row['container_id'])
        assert view['permanently_fenced'] is True and view['task_verification']=='unverified'
        assert all(x['execution_connected']is False for x in v['historical_receipts'])
        assert v['fixture_safety_cleanup']['absence_observed']is True
        if scenario.endswith('crash-cleanup'):
            assert v['child_exit_code']==86 and v['child_stdout_bytes']==v['child_stderr_bytes']==0
            assert v['created_container']['identity_matched']is True and v['created_container']['status']=='created'and v['created_container']['running']is False
            assert v['controlled_clock']['now']==v['controlled_clock']['lease_expires_at']+1
            clean=json.loads(row['cleanup_json']);assert sha(row['cleanup_json'].encode())==row['cleanup_sha256']
            assert clean['status']=='observed'and clean['container_id']==row['container_id']
            o=clean['observation'];assert o['outcome']=='removed_and_absent'and o['error_code']==''
            assert all(o[k]is True for k in ('identity_matched','remove_acknowledged','absence_observed','daemon_consistent'))
            assert row['assessment']=='unverified'and row['phase']=='unresolved'and row['start_intent']==0
        else:
            evidence=json.loads(row['result_json']);assert sha(row['result_json'].encode())==row['result_sha256']
            assert evidence==view['result']and evidence['container_id']==row['container_id']
            assert evidence['cleanup_confirmed']is True and evidence['execution_started']is True
            assert evidence['source_sha256']==proof['source_sha256']and evidence['commit_sha']==proof['candidate_sha']
            if scenario.endswith('wrong-result'):
                assert row['assessment']=='failed'and evidence['errors']==['case_mismatch']and evidence['passed_case_count']==0
            elif scenario.endswith('timeout'):
                assert row['assessment']=='unverified'and row['phase']=='unresolved'and 'timeout'in evidence['errors']
            elif scenario.endswith('running-cancel'):
                assert row['assessment']=='unverified'and row['cancel_requested']==1 and row['phase']=='unresolved'
                assert v['running_observation']['identity_matched']is True and v['running_observation']['running']is True
                assert evidence['passed_case_count']==1 and evidence['candidate_exit_code']==0 and evidence['errors']==[]
            else:
                assert row['assessment']=='passed'and row['phase']=='finished'and evidence['passed_case_count']==1 and evidence['errors']==[]
        observations.append({'environment':label,'scenario':scenario,'container_id':row['container_id'],'assessment':row['assessment']})
assert len(all_ids)==20
record={'test_commit':commit,'runtime_unchanged_from_full_suite':'437d306643b6529e600aa93c64e9ac0b9cf81d28','git_inputs':389,'sdist_inputs':178,'modules':62,'cases_each':37,'passed_each':36,'skipped_each':1,'skips':skips,'retained_cases':33,'added_cases':4,'scenario_observations':observations,'container_ids':sorted(all_ids),'artifacts':p['artifacts'],'full_new_commit_suite':'NOT RUN; test-only changes, prior full snapshot retained separately','release_gate':'BLOCKED','real_clients':'NOT RUN'}
(source/'root-audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
script="set -eu\n/root/jobs-env/bin/python - <<'OWNED_LIFECYCLE_POSTCHECK'\nimport json,subprocess\nids="+repr(sorted(all_ids))+"\np=subprocess.run(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,check=True,timeout=15)\nremaining=sorted(set(p.stdout.splitlines())&set(ids));print(json.dumps({'recorded_full_ids':len(ids),'remaining_recorded_ids':remaining,'all_recorded_ids_absent':not remaining}));assert not remaining\nOWNED_LIFECYCLE_POSTCHECK\n"
(source/'postcheck.sh').write_text(script,encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items()if k not in ('container_ids','scenario_observations')}))
