import site
if __name__=='__main__':
    site.addsitedir(r'D:\agentsync-debug\venv\Lib\site-packages')
    import pytest
    raise SystemExit(pytest.main(['-v','--basetemp=D:/agentsync-debug/b5realw/t','-o','cache_dir=D:/agentsync-debug/b5realw/pytest-cache','--junitxml=D:/agentsync-debug/b5realw/results.xml','tests/integration/test_candidate_execution.py','-k','unavailable_isolation or controlled_process_exit or actual_linux_docker']))
