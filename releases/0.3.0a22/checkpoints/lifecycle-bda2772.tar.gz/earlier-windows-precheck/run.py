import hashlib,json,os,shutil,subprocess,sys,time,zipfile
from pathlib import Path
ROOT=Path(r'D:\agentsync-debug\b5realw')
REPO=Path(r'F:\syuc\agentsync-execution-intent')
FILES=['tests/integration/test_candidate_execution.py']
PYTHON=Path(r'D:\agentsync-debug\venv\Scripts\python.exe')

def main():
    sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    subprocess.run(['git','archive','--format=zip','--output='+str(ROOT/'base.zip'),sha],cwd=REPO,check=True)
    with zipfile.ZipFile(ROOT/'base.zip') as archive:archive.extractall(ROOT/'source')
    for name in FILES:shutil.copyfile(REPO/name,ROOT/'source'/name)
    hashes={n:hashlib.sha256((ROOT/'source'/n).read_bytes()).hexdigest() for n in FILES}
    env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','COMSPEC','PATH','PATHEXT','OS','PROCESSOR_ARCHITECTURE','PROCESSOR_IDENTIFIER','NUMBER_OF_PROCESSORS'}}
    for n in ('home','tmp'):(ROOT/n).mkdir()
    env.update(PYTHONPATH=str(ROOT/'source'/'src'),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(ROOT/'tmp'),TMP=str(ROOT/'tmp'),HOME=str(ROOT/'home'),USERPROFILE=str(ROOT/'home'),APPDATA=str(ROOT/'home'),LOCALAPPDATA=str(ROOT/'home'),GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_SYSTEM=os.devnull,GIT_TERMINAL_PROMPT='0',RUFF_CACHE_DIR=str(ROOT/'ruff-cache'),MYPY_CACHE_DIR=str(ROOT/'mypy-cache'))
    meta=dict(base_sha=sha,changed_file_sha256=hashes,runtime=str(PYTHON),started=time.time(),checks=[])
    commands=[('ruff',[str(PYTHON),'-m','ruff','check',*FILES]),('format',[str(PYTHON),'-m','ruff','format','--check',*FILES]),('mypy',[str(PYTHON),'-m','mypy']),('collect',[str(PYTHON),'-m','pytest','--collect-only','-q','-p','no:cacheprovider','tests/integration/test_candidate_execution.py']),('pytest',[str(PYTHON),str(ROOT/'driver.py')])]
    for name,command in commands:
        with (ROOT/(name+'.log')).open('w',encoding='utf-8') as log:
            log.write(json.dumps(command)+'\n');log.flush()
            cp=subprocess.run(command,cwd=ROOT/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
        meta['checks'].append(dict(name=name,command=command,exit_code=cp.returncode))
        (ROOT/'result.json').write_text(json.dumps(meta,indent=2))
        print(json.dumps(meta['checks'][-1]),flush=True)
    meta['source_files_still_same']={n:hashlib.sha256((REPO/n).read_bytes()).hexdigest() for n in FILES}==hashes
    meta['finished']=time.time()
    (ROOT/'result.json').write_text(json.dumps(meta,indent=2))
if __name__=='__main__':main()
