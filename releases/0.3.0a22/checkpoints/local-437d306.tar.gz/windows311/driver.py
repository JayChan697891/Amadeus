import hashlib,importlib,json,os,platform,site,sys,time
from pathlib import Path
ROOT=Path(r'D:\agentsync-debug\b5p311f')
SRC=ROOT/'source'

def audit():
    results={}
    expected=json.loads((ROOT/'expected-modules.json').read_text())
    for name,digest in expected.items():
        relative=Path(name).relative_to('src').with_suffix('')
        parts=relative.parts
        modname='.'.join(parts[:-1] if parts[-1]=='__init__' else parts)
        module=importlib.import_module(modname)
        origin=Path(module.__file__).resolve()
        expected_path=(SRC/name).resolve()
        current=hashlib.sha256(origin.read_bytes()).hexdigest()
        assert origin==expected_path,(modname,str(origin),str(expected_path))
        assert current==digest,(modname,current,digest)
        results[modname]=dict(origin=str(origin),sha256=current)
    assert len(results)==62
    return results

def main():
    site.addsitedir(r'D:\agentsync-debug\alpha13-python311-1_06_4p9\venv\Lib\site-packages')
    assert sys.version_info[:2]==(3,11),sys.version
    result=dict(version=sys.version,platform=platform.platform(),sys_executable=sys.executable)
    before=audit()
    (ROOT/'modules-before.json').write_text(json.dumps(before,indent=2))
    import pytest
    selected=['tests/integration/test_candidate_execution.py::test_cleanup_keeps_observation_when_expired_executor_returns','tests/integration/test_candidate_execution.py::test_commit_ack_loss_preserves_fence_before_next_external_step','tests/integration/test_candidate_execution.py::test_schema12_upgrade_preserves_receipt_rows_and_missing_schema_fails_closed']
    selected.append('tests/unit/test_core_startup_diagnostic.py')
    args=['-v','--basetemp='+str(ROOT/'t'),'-o','cache_dir='+str(ROOT/'pytest-cache'),'--junitxml='+str(ROOT/'results.xml'),*selected]
    result['pytest_arguments']=args
    print(json.dumps(dict(version=sys.version,sys_executable=sys.executable,pytest_arguments=args)),flush=True)
    code=pytest.main(args)
    after=audit()
    (ROOT/'modules-after.json').write_text(json.dumps(after,indent=2))
    result.update(pytest_exit_code=int(code),modules_count=len(before),modules_before_after_identical=before==after)
    (ROOT/'driver-result.json').write_text(json.dumps(result,indent=2))
    raise SystemExit(code)
if __name__=='__main__':main()
