if __name__ == '__main__':
 import hashlib,importlib,json,pathlib,sys
 sys.dont_write_bytecode=True
 expected=json.loads(pathlib.Path(sys.argv[1]).read_text());destination=pathlib.Path(sys.argv[2]);base=pathlib.Path(sys.prefix).resolve()
 def verify():
  result={}
  for relative,digest in expected.items():
   name=relative.removesuffix('.py').replace('/','.').removesuffix('.__init__');module=importlib.import_module(name);origin=pathlib.Path(module.__file__).resolve()
   assert origin.is_relative_to(base) and hashlib.sha256(origin.read_bytes()).hexdigest()==digest
   result[relative]={'path':str(origin),'sha256':digest}
  return result
 before=verify();import agentsync;assert agentsync.__version__=='0.3.0a22'
 import pytest
 code=pytest.main(sys.argv[3:]);after=verify();assert before==after
 destination.write_text(json.dumps(after,indent=2));raise SystemExit(code)
