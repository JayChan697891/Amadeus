import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path('F:/syuc/agentsync-execution-intent')
linux = Path('D:/agentsync-debug/alpha22-linux-full-jeqlqg_1')
packages = Path('D:/agentsync-debug/p22-k5rd8poh')
minimum = Path('D:/agentsync-debug/b5p311f')
commit = '437d306643b6529e600aa93c64e9ac0b9cf81d28'
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))

def cases(path, count, skips):
    rows = list(ET.parse(path).getroot().iter('testcase'))
    ids = {(r.get('classname'), r.get('name')) for r in rows}
    assert len(rows) == len(ids) == count
    assert not any(r.find(t) is not None for r in rows for t in ('failure', 'error'))
    reasons = [{'id': r.get('classname') + '.' + r.get('name'),
                'reason': r.find('skipped').get('message')} for r in rows if r.find('skipped') is not None]
    assert len(reasons) == skips
    return ids, reasons

config = read(linux/'config.json')
result = read(linux/'evidence/result.json')
installed = read(packages/'result.json')
assert config['commit'] == result['commit'] == installed['commit'] == commit
assert installed['source_manifest'] == config['manifest']
assert result['passed'] is True and installed['passed'] is True
ids, skips = cases(linux/'evidence/junit.xml', 1868, 4)
old_rows = list(ET.parse('D:/agentsync-debug/alpha21-linux-full-tw3m83wo/evidence/junit.xml').getroot().iter('testcase'))
old_ids = {(r.get('classname'), r.get('name')) for r in old_rows}
assert len(old_ids) == 1835
renames = {}
for pair in old_ids:
 c,n=pair
 if c.endswith(('test_candidate_claim_migration','test_candidate_intent_migration')) and n=='test_future_schema13_rejected_without_any_mutation': renames[pair]=(c,'test_future_schema14_rejected_without_any_mutation')
 if c.endswith('test_candidate_queue_migration') and n=='test_future_schema_rejected_without_mutating_existing_database': renames[pair]=(c,'test_future_schema14_rejected_without_mutating_existing_database')
assert len(renames)==3
old_ids={renames.get(pair,pair)for pair in old_ids}
assert old_ids<=ids
assert len(ids - old_ids) == 33
assert all(c.endswith('test_candidate_execution') for c, n in ids - old_ids)
assert next(r for r in ET.parse(linux/'evidence/junit.xml').getroot().iter('testcase')
            if r.get('name') == 'test_actual_linux_docker_executes_candidate_not_base').find('skipped') is None

names = sorted(config['manifest'])
response = subprocess.run(['git', 'cat-file', '--batch'], cwd=repo, capture_output=True,
    input=('\n'.join(commit+':'+n for n in names)+'\n').encode(), check=True)
stream = io.BytesIO(response.stdout)
git_bytes = {}
for name in names:
    header = stream.readline().decode().split()
    assert header[1] == 'blob'
    data = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    assert digest(data) == config['manifest'][name], name
    if name.startswith(('src/', 'tests/', 'tools/')) or name == 'pyproject.toml':
        git_bytes[name] = data
modules = {n.removeprefix('src/'): digest(data) for n, data in git_bytes.items()
           if n.startswith('src/agentsync/') and n.endswith('.py')}
assert len(modules) == 62
assert read(linux/'evidence/imports-before.json') == read(linux/'evidence/imports-after.json') == modules

package_ids = []
for kind in ('wheel', 'sdist'):
    selected, _ = cases(packages/(kind+'.xml'), 6, 0)
    assert selected <= ids
    package_ids.append(selected)
    origins = read(packages/(kind+'-origins.json'))
    assert set(origins) == set(modules)
    for name, value in origins.items():
        assert value['sha256'] == modules[name]
        assert Path(value['path']).resolve().is_relative_to((packages/(kind+'-venv')).resolve())
    runtime = read(packages/(kind+'-runtime-provenance.json'))
    artifact = next(n for n in installed['artifacts'] if n.endswith('.whl' if kind == 'wheel' else '.tar.gz'))
    assert runtime['version'] == '0.3.0a22'
    assert runtime['direct_url']['archive_info']['hashes']['sha256'] == installed['artifacts'][artifact]
assert package_ids[0] == package_ids[1]
for name, sha in installed['artifacts'].items():
    assert digest((packages/'artifacts'/name).read_bytes()) == sha
with zipfile.ZipFile(next((packages/'artifacts').glob('*.whl'))) as archive:
    assert all(digest(archive.read(n)) == sha for n, sha in modules.items())
with tarfile.open(next((packages/'artifacts').glob('*.tar.gz'))) as archive:
    members = {m.name.split('/', 1)[1]: archive.extractfile(m).read()
               for m in archive if m.isfile() and '/' in m.name}
assert set(git_bytes) <= set(members)
assert all(members[n] == data for n, data in git_bytes.items())

minimum_ids, _ = cases(minimum/'results.xml', 8, 0)
assert minimum_ids <= ids
floor = read(minimum/'result.json')
assert floor['source_sha'] == commit
floor_inputs = {n.replace('\\', '/'): sha for n, sha in read(minimum/'source-before.json').items()}
assert floor_inputs == {n.replace('\\', '/'): sha for n, sha in read(minimum/'source-after.json').items()}
assert floor_inputs == config['manifest']
floor_modules = read(minimum/'modules-before.json')
assert floor_modules == read(minimum/'modules-after.json') and len(floor_modules) == 62
for relative, sha in modules.items():
    name = relative.removesuffix('.py').replace('/', '.').removesuffix('.__init__')
    assert floor_modules[name]['sha256'] == sha
    assert Path(floor_modules[name]['origin']).resolve() == (minimum/'source/src'/relative).resolve()
static = read(Path('D:/agentsync-debug/b5-final-static.json'))
assert static['commit'] == commit
assert static['ruff'] == static['format'] == static['mypy'] == 0
green, _ = cases(Path('D:/agentsync-debug/b5-cleanup-commit-green.xml'), 3, 0)
assert green <= ids
red = list(ET.parse('D:/agentsync-debug/b5-cleanup-race-red.xml').getroot().iter('testcase'))
assert len(red) == 1 and red[0].find('failure') is not None
observation = read(linux/'evidence/candidate-evidence/actual-candidate-execution.json')
assert observation['real_docker'] is True and observation['real_clients'] == 'NOT RUN'
row = observation['stored_execution']; proof = json.loads(row['proof_json'])
assert 'token_hash' not in row and digest(row['proof_json'].encode()) == row['proof_sha256']
assert digest(row['result_json'].encode()) == row['result_sha256']
assert row['assessment'] == 'passed' and row['phase'] == 'finished'
view = observation['current']['execution']
assert view['permanently_fenced'] is True and view['task_verification'] == 'unverified'
assert view['result']['cleanup_confirmed'] is True
expected_source=b"import json,sys\nfor line in sys.stdin:\n json.loads(line)\n print(json.dumps('candidate'))\n"
assert proof['source_sha256']==observation['expected_source_sha256']==digest(expected_source)
assert proof['candidate_sha']!=observation['base_sha']
assert proof['candidate_sha'] == observation['historical_receipts'][0]['candidate_sha']
assert all(receipt['execution_connected'] is False for receipt in observation['historical_receipts'])
assert proof['candidate_sha'] == view['result']['commit_sha']
evidence = view['result']
assert evidence['execution_started'] is True and evidence['candidate_exit_code'] == 0
assert evidence['errors'] == [] and evidence['container_id'] == row['container_id']
assert proof['case_count'] == 1
assert all(type(evidence[n]) is int and evidence[n] == 1 for n in
           ('expected_case_count', 'completed_case_count', 'checked_case_count', 'passed_case_count'))
expected_checks = set('owner image user environment entrypoint command workdir healthcheck network readonly privileged capabilities security namespaces mounts resources tmpfs groups logs'.split())
assert set(evidence['isolation']['checks']) == expected_checks
assert all(v is True for v in evidence['isolation']['checks'].values())
assert evidence['verifier_source_sha256'] == proof['verifier_sha256'] == modules['agentsync/verification/docker.py']

identities = set()
def visit(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'container_id' and isinstance(item, str) and re.fullmatch('[a-f0-9]{64}', item):
                identities.add(item)
            visit(item)
    elif isinstance(value, list):
        for item in value: visit(item)
records = []
for group in ('docker-evidence', 'owner-evidence', 'reconciliation-evidence', 'candidate-evidence'):
    for p in (linux/'evidence'/group).rglob('*.json'):
        records.append(p.relative_to(linux).as_posix()); visit(read(p))
assert len(records) == len(identities) == 27
current_ids = sorted(identities)
initial = Path('D:/agentsync-debug/alpha22-linux-full-fxu_vwl9')
initial_result = read(initial/'evidence/result.json')
assert initial_result['commit'] == 'a566f245e403d3f7c93045bae955f604c0708fa5'
assert initial_result['passed'] is False
assert initial_result['junit'] == {'tests':1868,'passed':1856,'failed':8,'errors':0,'skipped':4}
assert read(initial/'evidence/imports-before.json') == read(initial/'evidence/imports-after.json') == modules
failed_rows = list(ET.parse(initial/'evidence/junit.xml').getroot().iter('testcase'))
failed_cases = [(r.get('classname'), r.get('name')) for r in failed_rows if r.find('failure') is not None]
assert len(failed_cases) == 8 and all(renames.get(pair,pair) in ids for pair in failed_cases)
for group in ('docker-evidence', 'owner-evidence', 'reconciliation-evidence'):
    for p in (initial/'evidence'/group).rglob('*.json'): visit(read(p))
failed_candidate = read(initial/'failed-candidate.json')['stored_execution']
assert 'token_hash' not in failed_candidate
assert digest(failed_candidate['proof_json'].encode()) == failed_candidate['proof_sha256']
assert digest(failed_candidate['result_json'].encode()) == failed_candidate['result_sha256']
failed_evidence = json.loads(failed_candidate['result_json'])
assert failed_evidence['errors'] == ['protocol_failure'] and failed_evidence['stdout_bytes'] == 0
assert failed_evidence['cleanup_confirmed'] is True
visit(failed_candidate); visit(failed_evidence)
assert len(identities) == 54
audit = {'product_commit': commit, 'version': '0.3.0a22', 'schema': 13,
    'linux_full': result['junit'], 'retained_prior_case_ids': len(old_ids),
    'new_case_ids': len(ids-old_ids), 'renamed_future_schema_cases':3, 'skips': skips,
    'git_inputs_checked': len(names), 'sdist_inputs_checked': len(git_bytes),
    'runtime_modules': len(modules), 'windows_installed': installed['packages'],
    'windows311_selected': {'passed': 8, 'skipped': 0},
    'initial_failed_full': {'product_commit': initial_result['commit'], 'junit': initial_result['junit'], 'failed_cases': failed_cases},
    'current_container_ids': current_ids,
    'raw_records': records, 'container_ids': sorted(identities),
    'artifacts': installed['artifacts'], 'release_gate': 'BLOCKED', 'real_clients': 'NOT RUN'}
(linux/'root-audit.json').write_text(json.dumps(audit, indent=2)+'\n', encoding='utf-8')
script = "set -eu\n/root/jobs-env/bin/python - <<'OWNED_B5_POSTCHECK'\nimport json,subprocess\nids="+repr(sorted(identities))+"\np=subprocess.run(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,check=True,timeout=15)\nremaining=sorted(set(p.stdout.splitlines()) & set(ids))\nprint(json.dumps({'recorded_full_ids':len(ids),'remaining_recorded_ids':remaining,'all_recorded_ids_absent':not remaining}))\nassert not remaining\nOWNED_B5_POSTCHECK\n"
(linux/'postcheck.sh').write_text(script, encoding='utf-8', newline='\n')
print(json.dumps({k:v for k,v in audit.items() if k not in ('container_ids', 'raw_records', 'skips')}))
