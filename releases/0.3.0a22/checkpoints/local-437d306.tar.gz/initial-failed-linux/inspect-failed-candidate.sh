set -eu
/root/jobs-env/bin/python - <<'OWNED_FAILED_CANDIDATE'
import json,pathlib,sqlite3
root=pathlib.Path('/root/agentsync-alpha22-full-2c6a58307e704c20abb69f070b42428e')
folders=sorted({p.resolve() for p in (root/'test-temp').glob('test_actual_linux_docker_exec*')});assert len(folders)==1 and folders[0].is_relative_to(root.resolve())
dbs=list(folders[0].rglob('agentsync.db'));assert len(dbs)==1
db=sqlite3.connect(dbs[0].as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
row=dict(db.execute('SELECT * FROM candidate_executions').fetchone());del row['token_hash']
print(json.dumps({'fixture_database':str(dbs[0]),'stored_execution':row},indent=2))
OWNED_FAILED_CANDIDATE
