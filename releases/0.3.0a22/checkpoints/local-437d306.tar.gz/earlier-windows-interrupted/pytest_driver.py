import site
from pathlib import Path
if __name__=='__main__':
    site.addsitedir(r'D:\agentsync-debug\venv\Lib\site-packages')
    import pytest
    raise SystemExit(pytest.main(['-q','--basetemp=D:/agentsync-debug/b5s/t','-o','cache_dir=D:/agentsync-debug/b5s/pytest-cache','--junitxml=D:/agentsync-debug/b5s/focused.xml','tests/integration/test_candidate_execution.py','tests/integration/test_candidate_jobs.py','tests/integration/test_candidate_claims.py','tests/integration/test_candidate_intents.py','tests/integration/test_candidate_claim_migration.py','tests/integration/test_candidate_intent_migration.py','tests/unit/test_candidate_queue_migration.py','tests/unit/test_verification_executor.py']))
