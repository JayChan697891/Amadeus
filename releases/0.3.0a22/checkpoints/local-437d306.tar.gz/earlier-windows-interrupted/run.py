import hashlib,json,os,platform,subprocess,sys,time
from pathlib import Path
ROOT=Path(r'F:\syuc\agentsync-execution-intent')
OUT=Path(r'D:\agentsync-debug\b5s')

def source_identity():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    return {n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names if n and (ROOT/n).is_file()}

def main():
    os.chdir(ROOT)
    os.environ.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPYCACHEPREFIX=str(OUT/'pycache'),PYTHONPATH=str(ROOT/'src'),TMP=str(OUT/'tmp'),TEMP=str(OUT/'tmp'),MYPY_CACHE_DIR=str(OUT/'mypy'),RUFF_CACHE_DIR=str(OUT/'ruff'))
    (OUT/'tmp').mkdir()
    identity=source_identity()
    meta=dict(source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),runtime=sys.executable,version=sys.version,platform=platform.platform(),started=time.time(),source_hashes=identity,checks=[])
    (OUT/'start.json').write_text(json.dumps(meta,indent=2))
    checks=[('ruff',[sys.executable,'-m','ruff','check','.']),('format',[sys.executable,'-m','ruff','format','--check','.']),('mypy',[sys.executable,'-m','mypy']),('focused',[sys.executable,str(OUT/'pytest_driver.py')])]
    for name,cmd in checks:
        start=time.time()
        with (OUT/(name+'.log')).open('w',encoding='utf-8') as f:
            f.write(json.dumps(cmd)+'\n');f.flush()
            cp=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        item=dict(name=name,command=cmd,exit_code=cp.returncode,seconds=time.time()-start)
        meta['checks'].append(item)
        print(json.dumps(item),flush=True)
        (OUT/'progress.json').write_text(json.dumps(meta,indent=2))
    meta.update(finished=time.time(),source_after=source_identity(),git_status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True))
    meta['source_unchanged']=meta['source_after']==identity
    (OUT/'result.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(dict(source_unchanged=meta['source_unchanged'],git_status=meta['git_status'])),flush=True)
if __name__=='__main__':main()
