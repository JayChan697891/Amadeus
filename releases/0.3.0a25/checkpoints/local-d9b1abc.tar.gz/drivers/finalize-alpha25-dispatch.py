from pathlib import Path
import hashlib, json, subprocess, tarfile, io, datetime, xml.etree.ElementTree as ET

repo=Path('F:/syuc/agentsync-execution-intent')
out=Path('D:/agentsync-debug/alpha25-dispatch-ezd3m67l')
r=json.loads((out/'result.json').read_text(encoding='utf-8'))
assert r['passed'] and r['commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
review_path=Path('D:/agentsync-debug/astra-dispatch-review.json')
review=json.loads(review_path.read_text(encoding='utf-8'))
assert review['source_commit']==r['commit'] and review['findings']==[]
for name,digest in review['reviewed_files'].items():
    assert r['source_manifest'][name]==digest
requirements=json.loads((repo/'docs/acceptance/requirements.json').read_text(encoding='utf-8'))
assert len(requirements['requirements'])==42
assert all(item['execution_status']=='not_run' for item in requirements['requirements'])
for name,digest in r['source_manifest'].items():
    data=subprocess.check_output(['git','show',r['commit']+':'+name],cwd=repo)
    assert hashlib.sha256(data).hexdigest()==digest
    assert hashlib.sha256((out/'source'/name).read_bytes()).hexdigest()==digest
module_map=r['runtime_modules']
sets={}
for name,s in r['suites'].items():
    xml=out/(name+'.xml')
    assert hashlib.sha256(xml.read_bytes()).hexdigest()==s['junit_sha256']
    cases=list(ET.parse(xml).getroot().iter('testcase'))
    assert len(cases)==99 and not any(c.find(t)is not None for c in cases for t in ('failure','error','skipped'))
    sets[name]={c.get('classname')+'::'+c.get('name') for c in cases}
    assert len(sets[name])==99 and sets[name]==set(s['case_ids'])
    origins=json.loads((out/(name+'-origins.json')).read_text(encoding='utf-8'))
    assert set(origins)==set(module_map) and len(origins)==63
    base=(out/'source/src').resolve() if name.startswith('source') else (out/(name+'-venv')).resolve()
    for relative,record in origins.items():
        path=Path(record['path']).resolve()
        assert path.is_relative_to(base) and record['sha256']==module_map[relative]
        assert hashlib.sha256(path.read_bytes()).hexdigest()==module_map[relative]
assert all(s==sets['source314'] for s in sets.values())
for name,c in r['checks'].items():
    assert c['exit_code']==0
    assert hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()==c['log_sha256']
for name,digest in r['artifacts'].items():
    assert hashlib.sha256((out/'artifacts'/name).read_bytes()).hexdigest()==digest
matched_sdist=0
with tarfile.open(next((out/'artifacts').glob('*.tar.gz'))) as stream:
    for member in stream:
        relative='/'.join(Path(member.name).parts[1:])
        if member.isfile() and relative in r['source_manifest']:
            data=stream.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest()==r['source_manifest'][relative]
            matched_sdist+=1
old=Path('D:/agentsync-debug/alpha23-linux-full-9s8fju3r/evidence/junit.xml')
old_cases={c.get('classname')+'::'+c.get('name') for c in ET.parse(old).getroot().iter('testcase')}
selected_classes={case.rsplit('::',1)[0] for case in sets['source314']}
old_selected={case for case in old_cases if case.rsplit('::',1)[0] in selected_classes}
assert old_selected <= sets['source314']
added=sets['source314']-old_selected
assert len(old_selected)==74 and len(added)==25
audit={'frozen_source_sha':r['commit'],'git_files_independently_matched':len(r['source_manifest']),'runtime_modules_each':63,'sdist_git_members_matched':matched_sdist,'unique_cases_each':99,'retained_cases':74,'added_cases':25,'root_actual_file_junit_hash_origin_review':'PASS','code_review':'Bounded observer and nonblocking receipt share original admission; no retry/cancel/Core changes','release':'BLOCKED','not_run':['full repository suite at alpha25','Linux/macOS at alpha25','real Agent clients and autonomous relay','formal42 acceptance']}
(out/'root-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
members={}
members['review/astra-dispatch-review.json']=review_path
for p in out.iterdir():
    if p.is_file() and p.suffix in {'.json','.xml','.log','.py'}:
        members['evidence/'+p.name]=p
for p in (out/'artifacts').iterdir():members['artifacts/'+p.name]=p
for p in (Path('D:/agentsync-debug/verify-alpha25-dispatch.py'),Path(__file__)):
    members['drivers/'+p.name]=p
for p in Path('D:/agentsync-debug/m6-dispatch-wait-sol').glob('*.log'):
    members['development/'+p.name]=p
archive=repo/'releases/0.3.0a25/checkpoints/local-d9b1abc.tar.gz'
assert not archive.exists()
archive.parent.mkdir(parents=True,exist_ok=True)
manifest={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in members.items()}
with tarfile.open(archive,'w:gz') as stream:
    for n,p in members.items():stream.add(p,arcname=n,recursive=False)
    raw=json.dumps(manifest,indent=2).encode(); info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);stream.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as stream:
    for n,record in manifest.items():
        raw=stream.extractfile(n).read()
        assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
summary={'schema':'agentsync.local-checkpoint.v1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':r['commit'],'version':'0.3.0a25','scope':'M6 nonblocking dispatch receipt plus bounded observation; unchanged shared admission and no new execution authorization','source_windows314':{k:v for k,v in r['suites']['source314'].items() if k!='case_ids'},'source_windows311':{k:v for k,v in r['suites']['source311'].items() if k!='case_ids'},'fresh_windows_installed_each':{'passed':99,'failed':0,'errors':0,'skipped':0,'scope':'seven affected manager/protocol/Core-boundary modules, not whole repository'},'case_identity':{'retained':74,'added':25,'identical_unique_ids_each':99},'static':'Ruff, format176files and mypy63modules PASS','identity':audit,'artifacts':r['artifacts'],'evidence_archive':str(archive.relative_to(repo)).replace('\\','/'),'evidence_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'evidence_archive_bytes':archive.stat().st_size,'manifest_members':len(manifest),'M5':'BLOCKED','Release':'BLOCKED','formal_requirements':'42 not_run unchanged','real_clients':'NOT RUN; synthetic Python protocol fixtures and Mock only','Work_acceptance':'PENDING','not_run':audit['not_run'],'constraints':'No Actions, real-client execution, account changes, paid API, VM startup or main changes','development_failure_note':'No product test/check failure; initial commit rejected missing Git identity, corrected using per-command prior Codex identity without account/global config changes.'}
destination=repo/'docs/acceptance/evidence/alpha25-local-summary.json'
destination.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(out/'publication-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
