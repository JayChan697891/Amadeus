"""Single owned offline Windows full-suite observation; no automatic retry."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time
from datetime import datetime, timezone
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
REPO = Path(r"F:\syuc\agentsync-execution-intent")
COMMIT = "066b8dd0b0fc38b5f774854cd5915e433fc76695"
TIMEOUT = 7200
SOURCE = OUT / "source"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True), encoding="utf-8")


if SOURCE.exists() or (OUT / "result.json").exists():
    raise RuntimeError("Fresh observation directory required; do not reuse old evidence")
if git("rev-parse", "HEAD").decode().strip() != COMMIT:
    raise RuntimeError("Source HEAD changed before snapshot creation")
if git("status", "--porcelain").strip():
    raise RuntimeError("Source checkout is not clean before snapshot creation")
archive = OUT / "frozen-inputs.tar"
with archive.open("xb") as target:
    subprocess.run(["git", "archive", "--format=tar", COMMIT], cwd=REPO, stdout=target, check=True)
expected = {}
with tarfile.open(archive) as frozen:
    for member in frozen.getmembers():
        if member.isdir():
            continue
        if not member.isfile() or ".git" in Path(member.name).parts:
            raise RuntimeError("Snapshot contains unsupported archive entry")
        expected[member.name] = hashlib.sha256(frozen.extractfile(member).read()).hexdigest()
    SOURCE.mkdir()
    frozen.extractall(SOURCE, filter="data")
tracked = set(git("ls-tree", "-r", "--name-only", COMMIT).decode("utf-8").splitlines())
if set(expected) != tracked:
    raise RuntimeError("Git archive did not preserve every tracked input")
before = {name: digest(SOURCE / name) for name in expected}
if before != expected:
    raise RuntimeError("Extracted tracked inputs differ from frozen Git archive")
save("inputs-before.json", before)
modules = {name: value for name, value in before.items()
           if name.startswith("src/agentsync/") and name.endswith(".py")}
if len(modules) != 60:
    raise RuntimeError("Expected exactly 60 frozen source modules")
save("modules-before.json", modules)

environment = os.environ.copy()
for key in list(environment):
    if key.startswith("AGENTSYNC_") or key in {"PYTEST_ADDOPTS", "PYTEST_PLUGINS", "PYTHONHOME"}:
        del environment[key]
environment.update(PYTHONPATH=str(SOURCE / "src"), PYTHONDONTWRITEBYTECODE="1",
                   PYTHONUNBUFFERED="1", TEMP=str(OUT), TMP=str(OUT))
command = [r"D:\python\python.exe", "-B", "-u", str(OUT / "bootstrap.py")]
result = {
    "commit": COMMIT, "scope": "complete offline Windows source snapshot, existing debug packages",
    "archive_sha256": digest(archive), "tracked_inputs": len(before), "module_count": len(modules),
    "source_snapshot": str(SOURCE), "timeout_seconds": TIMEOUT, "command": command,
    "status": "RUNNING", "passed": False, "formal_release": "BLOCKED",
    "formal_requirements": "42 not_run", "real_clients": "NOT RUN",
    "started_utc": datetime.now(timezone.utc).isoformat(),
    "pid_cleanup_scope": "only directly owned pytest parent handle; descendant cleanup not claimed",
}
save("result.json", result)
start = time.monotonic()
print(json.dumps({"output": str(OUT), "commit": COMMIT, "inputs": len(before), "modules": 60}), flush=True)
with (OUT / "pytest.log").open("xb") as log:
    child = subprocess.Popen(command, cwd=SOURCE, env=environment, stdout=log, stderr=subprocess.STDOUT)
    result["owned_pytest_pid"] = child.pid
    save("pids.json", {"controller_pid": os.getpid(), "pytest_pid": child.pid,
                       "owned_executable": command[0], "created_utc": datetime.now(timezone.utc).isoformat(),
                       "source_snapshot": str(SOURCE)})
    save("result.json", result)
    timed_out = False
    while True:
        remaining = TIMEOUT - (time.monotonic() - start)
        try:
            code = child.wait(timeout=min(30, max(remaining, 0.001)))
            break
        except subprocess.TimeoutExpired:
            if time.monotonic() - start >= TIMEOUT:
                timed_out = True
                child.terminate()
                try:
                    code = child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    child.kill()
                    code = child.wait(timeout=10)
                break
            lines = (OUT / "phases.jsonl").read_text(encoding="ascii").splitlines() if (OUT / "phases.jsonl").exists() else []
            observed = []
            for line in lines:
                try:
                    observed.append(json.loads(line))
                except ValueError:
                    pass
            phases = [row for row in observed if row["event"] == "phase"]
            progress = {"elapsed_s": round(time.monotonic() - start, 3),
                        "observed_phase_reports": len(phases),
                        "failed_phase_reports": sum(row["outcome"] == "failed" for row in phases),
                        "last_observation": observed[-1] if observed else None,
                        "status": "RUNNING / INCOMPLETE"}
            save("progress.json", progress)
            print(json.dumps(progress, ensure_ascii=True), flush=True)

result.update(exit_status=code, timed_out=timed_out, elapsed_seconds=time.monotonic() - start,
              completed_utc=datetime.now(timezone.utc).isoformat(),
              status="TIMED OUT / NOT COMPLETED" if timed_out else "COMPLETED")
after = {name: digest(SOURCE / name) if (SOURCE / name).is_file() else None for name in expected}
save("inputs-after.json", after)
save("modules-after.json", {name: after[name] for name in modules})
result["tracked_inputs_unchanged"] = after == before
result["modules_unchanged"] = all(after[name] == value for name, value in modules.items())
result["extra_snapshot_files"] = sorted(str(path.relative_to(SOURCE)) for path in SOURCE.rglob("*")
                                        if path.is_file() and path.relative_to(SOURCE).as_posix() not in expected)
runtime = json.loads((OUT / "runtime.json").read_text(encoding="utf-8")) if (OUT / "runtime.json").exists() else {}
result["runtime_modules_match"] = {name: value["sha256"] for name, value in runtime.get("modules", {}).items()} == modules
if (OUT / "junit.xml").exists():
    cases = list(ET.parse(OUT / "junit.xml").getroot().iter("testcase"))
    result["junit"] = {
        "tests": len(cases),
        "passed": sum(not any(item.find(tag) is not None for tag in ("failure", "error", "skipped")) for item in cases),
        "failed": sum(item.find("failure") is not None for item in cases),
        "errors": sum(item.find("error") is not None for item in cases),
        "skipped": sum(item.find("skipped") is not None for item in cases),
    }
    result["skip_reasons"] = [{"case": item.attrib, "reason": item.find("skipped").attrib}
                              for item in cases if item.find("skipped") is not None]
    result["junit_sha256"] = digest(OUT / "junit.xml")
    collected = json.loads((OUT / "collected.json").read_text(encoding="utf-8"))
    result["all_collected_cases_reported"] = len(cases) == len(collected) == 1835
result["passed"] = (not timed_out and code == 0 and result["tracked_inputs_unchanged"]
                    and result["modules_unchanged"] and result["runtime_modules_match"]
                    and result.get("all_collected_cases_reported", False)
                    and result.get("junit", {}).get("failed", 1) == 0
                    and result.get("junit", {}).get("errors", 1) == 0)
result["log_sha256"] = digest(OUT / "pytest.log")
result["driver_sha256"] = digest(Path(__file__))
result["bootstrap_sha256"] = digest(OUT / "bootstrap.py")
save("result.json", result)
print(json.dumps(result, ensure_ascii=True), flush=True)
raise SystemExit(0 if result["passed"] else 1)
