if __name__ == '__main__':
    """Run frozen offline source with existing debug packages and private phase records."""
    import hashlib
    import importlib
    import json
    import os
    from pathlib import Path
    import platform
    import site
    import sys
    from time import perf_counter
    
    OUT = Path(__file__).resolve().parent
    SOURCE = OUT / "source"
    site.addsitedir(r"D:\agentsync-debug\venv\Lib\site-packages")
    # Test-launched Python subprocesses retain the actual existing venv bootstrap.
    # The top-level process itself is the directly owned base interpreter.
    sys.executable = r"D:\agentsync-debug\venv\Scripts\python.exe"
    import pytest
    
    expected = json.loads((OUT / "inputs-before.json").read_text(encoding="utf-8"))
    modules = {}
    for name in expected:
        if not name.startswith("src/agentsync/") or not name.endswith(".py"):
            continue
        module_name = name[4:-3].replace("/", ".")
        if module_name.endswith(".__init__"):
            module_name = module_name[:-9]
        module = importlib.import_module(module_name)
        actual = Path(module.__file__).resolve()
        if actual != (SOURCE / name).resolve():
            raise RuntimeError("Runtime module origin does not match frozen snapshot")
        digest = hashlib.sha256(actual.read_bytes()).hexdigest()
        if digest != expected[name]:
            raise RuntimeError("Runtime module bytes do not match frozen snapshot")
        modules[name] = {"path": str(actual), "sha256": digest}
    if len(modules) != 60:
        raise RuntimeError("Expected exactly 60 runtime modules")
    (OUT / "runtime.json").write_text(json.dumps({
        "python": platform.python_version(), "pytest": pytest.__version__,
        "actual_owned_executable": r"D:\python\python.exe",
        "test_child_executable": sys.executable, "prefix": sys.prefix,
        "modules": modules,
    }, indent=2), encoding="utf-8")
    
    
    class Recorder:
        def __init__(self):
            self.started = perf_counter()
            self.file = (OUT / "phases.jsonl").open("x", encoding="ascii")
    
        def write(self, record):
            record["elapsed_s"] = round(perf_counter() - self.started, 6)
            self.file.write(json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n")
            self.file.flush()
    
        def pytest_collection_finish(self, session):
            nodeids = [item.nodeid for item in session.items]
            (OUT / "collected.json").write_text(json.dumps(nodeids, indent=2), encoding="utf-8")
            self.write({"event": "collected", "count": len(nodeids)})
    
        def pytest_runtest_logstart(self, nodeid, location):
            self.write({"event": "case_start", "nodeid": nodeid})
    
        def pytest_runtest_logreport(self, report):
            self.write({"event": "phase", "nodeid": report.nodeid, "phase": report.when,
                        "outcome": report.outcome, "duration_s": report.duration})
    
        def pytest_sessionfinish(self, session, exitstatus):
            self.write({"event": "finish", "exit_status": int(exitstatus),
                        "collected": session.testscollected, "failed": session.testsfailed})
    
        def pytest_unconfigure(self, config):
            self.file.close()
    
    
    raise SystemExit(pytest.main([
        "-vv", "--durations=0", "tests", "--junitxml", str(OUT / "junit.xml"),
        "--basetemp", str(OUT / "test-tmp"), "-o", "cache_dir=" + str(OUT / "pytest-cache"),
    ], plugins=[Recorder()]))
