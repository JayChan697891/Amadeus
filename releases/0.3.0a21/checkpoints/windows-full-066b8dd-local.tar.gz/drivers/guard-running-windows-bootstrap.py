import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

out=Path(r'D:\agentsync-debug\alpha21-windows-complete-sol-6cd849b2')
path=out/'bootstrap.py'
original=path.read_bytes()
assert b"if __name__ == '__main__':" not in original
phases=(out/'phases.jsonl').read_text().splitlines()
assert not any('test_two_claimants_have_exactly_one_winner' in row for row in phases)
backup=out/'bootstrap-before-guard.py.txt'
with backup.open('xb') as stream: stream.write(original)
updated="if __name__ == '__main__':\n"+'\n'.join('    '+line for line in original.decode('utf-8').splitlines())+'\n'
compile(updated,str(path),'exec')
temporary=out/'bootstrap-guarded.tmp'
temporary.write_text(updated,encoding='utf-8',newline='\n')
os.replace(temporary,path)
record={
 'time_utc':datetime.now(timezone.utc).isoformat(),
 'scope':'private test bootstrap only; no product/test/fixture edits or test restart',
 'reason':'guard multiprocessing spawn re-import from recursively invoking pytest',
 'original_sha256':hashlib.sha256(original).hexdigest(),
 'guarded_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'original_preserved_as':backup.name,
 'parent_already_loaded_original':True,
 'spawn_case_not_yet_started':True,
 'observed_phase_lines_at_intervention':len(phases),
 'reproduction':'use guarded bootstrap from start; original and intervention retained',
 'formal_release':'BLOCKED',
}
(out/'bootstrap-intervention.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
