import hashlib,io,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path

repo=Path(r'F:\syuc\agentsync-execution-intent');out=Path(r'D:\agentsync-debug\alpha21-windows-complete-sol-6cd849b2')
r=json.loads((out/'result.json').read_text(encoding='utf-8'))
assert r['passed'] is True and r['status']=='COMPLETED' and not r['timed_out'] and r['exit_status']==0
assert r['junit']=={'tests':1835,'passed':1800,'failed':0,'errors':0,'skipped':35}
before=json.loads((out/'inputs-before.json').read_text(encoding='utf-8'));after=json.loads((out/'inputs-after.json').read_text(encoding='utf-8'))
assert before==after and len(before)==377 and r['extra_snapshot_files']==[]
names=list(before)
response=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(r['commit']+':'+n for n in names)+'\n').encode(),cwd=repo,capture_output=True,check=True)
stream=io.BytesIO(response.stdout)
for n in names:
    head=stream.readline().decode().split();assert head[1]=='blob'
    data=stream.read(int(head[2]));assert stream.read(1)==b'\n'
    assert hashlib.sha256(data).hexdigest()==before[n]
runtime=json.loads((out/'runtime.json').read_text(encoding='utf-8'))
expected=json.loads(Path(r'D:\agentsync-debug\alpha21-windows-lkympmjv\result.json').read_text(encoding='utf-8'))['runtime_modules']
assert len(runtime['modules'])==60
assert {n.removeprefix('src/'):v['sha256']for n,v in runtime['modules'].items()}==expected
for n,v in runtime['modules'].items():assert Path(v['path']).resolve()==(out/'source'/n).resolve()
def ids(path):
    rows=list(ET.parse(path).getroot().iter('testcase'));values={(c.get('classname'),c.get('name'))for c in rows};assert len(values)==len(rows)==1835
    return values,rows
actual,rows=ids(out/'junit.xml');linux,_=ids(Path(r'D:\agentsync-debug\alpha21-linux-full-tw3m83wo\evidence\junit.xml'))
assert actual==linux
spawn=[c for c in rows if c.get('name')=='test_two_claimants_have_exactly_one_winner[processes]'];assert len(spawn)==1 and not any(spawn[0].find(t)is not None for t in ('failure','error','skipped'))
phases=[json.loads(line)for line in (out/'phases.jsonl').read_text(encoding='ascii').splitlines()]
assert phases[-1]['event']=='finish' and phases[-1]['exit_status']==0 and phases[-1]['collected']==1835 and phases[-1]['failed']==0
intervention=json.loads((out/'bootstrap-intervention.json').read_text(encoding='utf-8'))
assert hashlib.sha256((out/'bootstrap-before-guard.py.txt').read_bytes()).hexdigest()==intervention['original_sha256']
assert hashlib.sha256((out/'bootstrap.py').read_bytes()).hexdigest()==intervention['guarded_sha256']==r['bootstrap_sha256']
result={'frozen_commit':r['commit'],'runtime_product_commit':'cb71f0e232253561a6da4ae5f346b312f94ce91b','source_inputs_rehashed':377,'module_origins_and_hashes':60,'junit':r['junit'],'all_case_ids_equal_linux':True,'spawn_case_passed_after_documented_bootstrap_guard':True,'bootstrap_intervention':intervention,'elapsed_seconds':r['elapsed_seconds'],'warnings':['PytestAssertRewriteWarning: anyio was imported before pytest plugin rewriting; retained, not a product failure'],'pid_cleanup_scope':'owned controller3756 and pytest7108 absent by CIM; no universal descendant cleanup assertion','formal_release':'BLOCKED','actual_clients':'NOT RUN'}
(out/'root-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
