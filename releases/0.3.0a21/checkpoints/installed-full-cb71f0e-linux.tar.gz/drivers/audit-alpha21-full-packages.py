import hashlib,io,json,re,subprocess,tarfile,xml.etree.ElementTree as ET,zipfile
from pathlib import Path

repo=Path(r'F:\syuc\agentsync-execution-intent')
out=Path(r'D:\agentsync-debug\alpha21-linux-full-packages-5p9beet9')
package=Path(r'D:\agentsync-debug\alpha21-windows-lkympmjv')
config=json.loads((out/'config.json').read_text())
result=json.loads((out/'evidence/result.json').read_text())
assert result['status']=='FULL_INSTALLED_SUITES_PASS'
def sha(data):return hashlib.sha256(data).hexdigest()
def cases(path):
    rows=list(ET.parse(path).getroot().iter('testcase'))
    ids={(r.get('classname'),r.get('name'))for r in rows}
    assert len(rows)==len(ids)==1835
    assert not any(r.find(t)is not None for r in rows for t in ('failure','error'))
    skipped=[{'id':r.get('classname')+'.'+r.get('name'),'reason':r.find('skipped').get('message')}for r in rows if r.find('skipped')is not None]
    assert len(skipped)==3
    return ids,skipped
expected_ids,expected_skips=cases(Path(r'D:\agentsync-debug\alpha21-linux-full-tw3m83wo\evidence\junit.xml'))
records=[];identities=set()
def visit(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if key=='container_id' and isinstance(item,str) and re.fullmatch('[a-f0-9]{64}',item):identities.add(item)
            visit(item)
    elif isinstance(value,list):
        for item in value:visit(item)
for kind in ('wheel','sdist'):
    ids,skips=cases(out/'evidence'/f'{kind}-junit.xml')
    assert ids==expected_ids and skips==expected_skips
    origins=json.loads((out/'evidence'/f'{kind}-origins.json').read_text())
    assert set(origins)==set(config['modules']) and len(origins)==60
    for name,value in origins.items():
        assert value['sha256']==config['modules'][name]
        assert value['path'].startswith(config['guest']+'/'+kind+'/lib/')
        assert '/site-packages/agentsync/' in value['path']
    artifact=config[kind]
    data=(package/'artifacts'/artifact).read_bytes()
    assert sha(data)==config['artifacts'][artifact]
    direct=json.loads((out/'evidence'/f'{kind}-direct-url.json').read_text())
    assert direct['archive_info']['hashes']['sha256']==sha(data)
    for group in ('docker','owner','reconciliation'):
        for path in (out/'evidence'/f'{kind}-{group}').rglob('*.json'):
            records.append(path.relative_to(out).as_posix());visit(json.loads(path.read_text()))
assert len(records)==52 and len(identities)==52
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',config['commit']],cwd=repo,text=True).splitlines()
mandatory={n for n in tracked if n.startswith(('src/','tests/','tools/')) or n=='pyproject.toml'}
with tarfile.open(package/'artifacts'/config['sdist']) as archive:
    files={m.name.split('/',1)[1]:archive.extractfile(m).read()for m in archive if m.isfile() and '/' in m.name}
assert mandatory<=set(files), sorted(mandatory-set(files))
names=sorted(mandatory)
response=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(config['commit']+':'+n for n in names)+'\n').encode(),cwd=repo,capture_output=True,check=True)
stream=io.BytesIO(response.stdout)
for name in names:
    header=stream.readline().decode().split();assert header[1]=='blob'
    data=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    assert data==files[name],name
with zipfile.ZipFile(package/'artifacts'/config['wheel']) as wheel:
    assert all(sha(wheel.read(n))==h for n,h in config['modules'].items())
record={'product_commit':config['commit'],'version':'0.3.0a21','packages':result['packages'],'complete_case_sets_equal_source':True,'case_count_each':1835,'actual_installed_module_hashes_each':60,'git_test_tool_source_inputs_compared':len(names),'skips_each':expected_skips,'records':records,'container_ids':sorted(identities),'release':'BLOCKED','real_clients':'NOT RUN'}
(out/'root-audit.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
script="set -eu\n/root/jobs-env/bin/python - <<'OWNED_PACKAGE_POSTCHECK'\nimport json,subprocess\nids="+repr(sorted(identities))+"\np=subprocess.run(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,check=True,timeout=15)\nremaining=sorted(set(p.stdout.splitlines()).intersection(ids))\nprint(json.dumps({'recorded_full_ids':len(ids),'remaining_recorded_ids':remaining,'all_recorded_ids_absent':not remaining}))\nassert not remaining\nOWNED_PACKAGE_POSTCHECK\n"
(out/'postcheck.sh').write_text(script,encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items()if k not in ('container_ids','records','skips_each')}))
