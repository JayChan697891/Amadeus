import json, os, runpy, subprocess, tempfile
from pathlib import Path
repo=Path(r'F:\syuc\agentsync-execution-intent')
out=Path(tempfile.mkdtemp(prefix='plan-ascii-repro-',dir=r'D:\agentsync-debug'))
data=runpy.run_path(str(repo/'tests/unit/test_planning_cli.py'))['payload']()
project='项目😀'
data['project_id']=project
data['state']['project']['id']=project
for group in ('agents','sessions','tasks'):
    for item in data['state'][group]: item['project_id']=project
env=os.environ.copy();env.update(PYTHONIOENCODING='ascii',PYTHONPATH=str(repo/'src'),PYTHONDONTWRITEBYTECODE='1',HOME=str(out),USERPROFILE=str(out),APPDATA=str(out),LOCALAPPDATA=str(out),AGENTSYNC_DATA_DIR=str(out/'unused-state'))
p=subprocess.run([r'D:\agentsync-debug\venv\Scripts\python.exe','-B','-m','agentsync','plan'],input=json.dumps(data).encode(),cwd=out,env=env,capture_output=True,timeout=20)
(out/'stdout').write_bytes(p.stdout);(out/'stderr').write_bytes(p.stderr)
print(json.dumps({'evidence':str(out),'exit_status':p.returncode,'UnicodeEncodeError':b'UnicodeEncodeError' in p.stderr,'no_data_state':not(out/'unused-state').exists()}))
