import hashlib
import json
import os
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path(r'F:\syuc\agentsync-execution-intent')
out = Path(tempfile.mkdtemp(prefix='plan-ascii-root-', dir=r'D:\agentsync-debug'))
selectors = ['tests/unit/test_usage_cli.py', 'tests/unit/test_usage.py', 'tests/unit/test_planning_cli.py', 'tests/security/test_m5_owner_cli_inputs.py', 'tests/integration/test_transports.py', 'tests/integration/test_mock_workflow.py']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
modules = {p.relative_to(repo / 'src').as_posix(): sha(p) for p in (repo / 'src/agentsync').rglob('*.py')}
env = os.environ.copy()
env.update(PYTHONPATH=str(repo / 'src'), PYTHONDONTWRITEBYTECODE='1', TEMP=str(out), TMP=str(out), RUFF_CACHE_DIR=str(out / 'ruff'), MYPY_CACHE_DIR=str(out / 'mypy'))
report = {'commit': commit, 'selectors': selectors, 'modules': modules, 'checks': {}, 'release': 'BLOCKED'}

def save():
    (out / 'result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

def run(name, args):
    p = subprocess.run(args, cwd=repo, env=env, capture_output=True, timeout=180)
    (out / (name + '.stdout')).write_bytes(p.stdout)
    (out / (name + '.stderr')).write_bytes(p.stderr)
    report['checks'][name] = {'exit_status': p.returncode}
    save()
    assert p.returncode == 0, name

print(out, flush=True)
save()
for name, python in [('py314', r'D:\agentsync-debug\venv\Scripts\python.exe'), ('py311', r'D:\agentsync-debug\alpha13-python311-1_06_4p9\venv\Scripts\python.exe')]:
    xml = out / (name + '.xml')
    run(name, [python, '-m', 'pytest', '-q', *selectors, '--junitxml', str(xml), '--basetemp', str(out / (name + '-tmp')), '-o', 'cache_dir=' + str(out / (name + '-cache'))])
    cases = ET.parse(xml).getroot().findall('.//testcase')
    report['checks'][name].update(tests=len(cases), passed=sum(not any(c.find(t) is not None for t in ('failure', 'error', 'skipped')) for c in cases), failed=sum(c.find('failure') is not None for c in cases), errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases), junit_sha256=sha(xml))
    save()
python = r'D:\agentsync-debug\venv\Scripts\python.exe'
run('ruff', [python, '-m', 'ruff', 'check', '.'])
run('format', [python, '-m', 'ruff', 'format', '--check', '.'])
run('mypy', [python, '-m', 'mypy'])
run('diff', ['git', 'diff', '--check'])
report['source_unchanged'] = all(sha(repo / 'src' / p) == h for p, h in modules.items())
assert report['source_unchanged']
report['passed'] = True
save()
print(json.dumps({'evidence': str(out), 'commit': commit, 'modules': len(modules), 'checks': report['checks'], 'passed': True}), flush=True)
