import json, os, subprocess, time, xml.etree.ElementTree as ET
from pathlib import Path
root=Path(r'D:\agentsync-debug\windows-pending-sol-3f34dd87')
cases=[line for line in (root/'collect-bootstrap.log').read_text(encoding='utf-8').splitlines() if line.startswith('tests/') and '::' in line]
selected=cases[129:131]
args=['-vv','--durations=0','--junitxml='+str(root/'isolated.xml'),'--basetemp='+str(root/'isolated-tmp'),'-o','cache_dir='+str(root/'pytest-cache'),*selected]
script="import site;site.addsitedir(r'D:\\agentsync-debug\\venv\\Lib\\site-packages');import pytest;raise SystemExit(pytest.main("+repr(args)+"))"
command=[r'D:\python\python.exe','-B','-c',script]
env=os.environ.copy()
env.update(PYTHONPATH=r'F:\syuc\agentsync-execution-intent\src',PYTHONDONTWRITEBYTECODE='1',TEMP=str(root),TMP=str(root))
start=time.monotonic()
with (root/'isolated.log').open('wb') as output:
 child=subprocess.Popen(command,cwd=r'F:\syuc\agentsync-execution-intent',env=env,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try: code=child.wait(timeout=120)
 except subprocess.TimeoutExpired:
  timed_out=True;child.kill();code=child.wait(timeout=10)
result=dict(selected_nodeids=selected,elapsed_seconds=time.monotonic()-start,exit_status=code,timed_out=timed_out,owned_parent_pid=child.pid,timeout_seconds=120,environment_scope='same Python3.14 base; site.addsitedir debug venv packages; frozen source on PYTHONPATH',junit_exists=(root/'isolated.xml').is_file())
if result['junit_exists']:
 tree=ET.parse(root/'isolated.xml')
 result['cases']=[dict(nodeid=item.attrib.get('classname','')+'::'+item.attrib['name'],seconds=float(item.attrib['time']),status='failed' if item.find('failure') is not None else 'error' if item.find('error') is not None else 'skipped' if item.find('skipped') is not None else 'passed') for item in tree.iter('testcase')]
(root/'isolated-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
