import json, os, subprocess, time
from pathlib import Path
root = Path(r'D:\agentsync-debug\windows-pending-sol-3f34dd87')
env = os.environ.copy()
env.update(PYTHONPATH=os.pathsep.join([r'F:\syuc\agentsync-execution-intent\src',r'D:\agentsync-debug\venv\Lib\site-packages']), PYTHONDONTWRITEBYTECODE='1', TEMP=str(root), TMP=str(root))
command = [r'D:\python\python.exe','-B','-m','pytest','--collect-only','-q','-o',f'cache_dir={root / "pytest-cache"}']
started = time.monotonic()
with (root/'collect.log').open('wb') as output:
    child = subprocess.Popen(command,cwd=r'F:\syuc\agentsync-execution-intent',env=env,stdout=output,stderr=subprocess.STDOUT)
    timed_out = False
    try:
        code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timed_out = True
        child.kill()
        code = child.wait(timeout=10)
result = dict(command=command,elapsed_seconds=time.monotonic()-started,exit_status=code,timed_out=timed_out,owned_parent_pid=child.pid,environment_scope='direct same Python3.14 base with debug venv site-packages and source explicit on PYTHONPATH')
(root/'collect-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
if code == 0:
    cases = [line for line in (root/'collect.log').read_text(encoding='utf-8').splitlines() if line.startswith('tests/') and '::' in line]
    print(json.dumps(dict(count=len(cases),near_progress=[dict(index=i+1,nodeid=cases[i]) for i in range(124,min(134,len(cases)))]),indent=2))
