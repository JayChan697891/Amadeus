import json, os, subprocess, time
from pathlib import Path
root=Path(r'D:\agentsync-debug\windows-pending-sol-3f34dd87')
env=os.environ.copy()
env.update(PYTHONPATH=r'F:\syuc\agentsync-execution-intent\src',PYTHONDONTWRITEBYTECODE='1',TEMP=str(root),TMP=str(root))
script="import site;site.addsitedir(r'D:\\agentsync-debug\\venv\\Lib\\site-packages');import pytest;raise SystemExit(pytest.main(['--collect-only','-q','-o',r'cache_dir=D:\\agentsync-debug\\windows-pending-sol-3f34dd87\\pytest-cache']))"
command=[r'D:\python\python.exe','-B','-c',script]
start=time.monotonic()
with (root/'collect-bootstrap.log').open('wb') as output:
 child=subprocess.Popen(command,cwd=r'F:\syuc\agentsync-execution-intent',env=env,stdout=output,stderr=subprocess.STDOUT)
 timed_out=False
 try: code=child.wait(timeout=60)
 except subprocess.TimeoutExpired:
  timed_out=True;child.kill();code=child.wait(timeout=10)
result=dict(exit_status=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-start,owned_parent_pid=child.pid,command=command)
(root/'collect-bootstrap-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
if code==0:
 cases=[line for line in (root/'collect-bootstrap.log').read_text(encoding='utf-8').splitlines() if line.startswith('tests/') and '::' in line]
 print(json.dumps(dict(count=len(cases),near_progress=[dict(index=i+1,nodeid=cases[i]) for i in range(124,min(134,len(cases)))]),indent=2))
