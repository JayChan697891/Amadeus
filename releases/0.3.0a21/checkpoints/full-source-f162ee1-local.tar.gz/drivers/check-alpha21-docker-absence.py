import json,re
from pathlib import Path
base=Path(r'D:\agentsync-debug\alpha21-linux-full-tw3m83wo')
identities=set(); records=[]
def visit(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key=='container_id' and isinstance(item,str) and re.fullmatch('[0-9a-f]{64}',item): identities.add(item)
   visit(item)
 elif isinstance(value,list):
  for item in value: visit(item)
for group in ('docker-evidence','owner-evidence','reconciliation-evidence'):
 for path in (base/'evidence'/group).rglob('*.json'):
  visit(json.loads(path.read_text()));records.append(path.relative_to(base).as_posix())
assert len(records)==26 and identities
script="set -eu\n/root/jobs-env/bin/python - <<'OWNED_DOCKER_POSTCHECK'\nimport json,subprocess\nidentities="+repr(sorted(identities))+"\np=subprocess.run(['docker','ps','-a','--no-trunc','--format','{{.ID}}'],capture_output=True,text=True,check=True,timeout=15)\nremaining=set(p.stdout.splitlines()).intersection(identities)\nprint(json.dumps({'recorded_full_ids':len(identities),'remaining_recorded_ids':sorted(remaining),'all_recorded_ids_absent':not remaining}))\nassert not remaining\nOWNED_DOCKER_POSTCHECK\n"
(base/'postcheck.sh').write_text(script,encoding='utf-8',newline='\n')
(base/'docker-records.json').write_text(json.dumps({'records':records,'container_ids':sorted(identities)},indent=2),encoding='utf-8')
print(json.dumps({'raw_records':len(records),'recorded_full_ids':len(identities)}))
