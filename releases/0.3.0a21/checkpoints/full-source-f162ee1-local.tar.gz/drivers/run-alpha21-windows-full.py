import hashlib,json,os,subprocess,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path(r'F:\syuc\agentsync-execution-intent'); out=Path(tempfile.mkdtemp(prefix='alpha21-windows-full-',dir=r'D:\agentsync-debug'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit=='f162ee1cf8f18c9961defec025baabf9801138ef5' if False else commit.startswith('f162ee1')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
modules={p.relative_to(repo/'src').as_posix():sha(p) for p in (repo/'src/agentsync').rglob('*.py')}; assert len(modules)==60
env=os.environ.copy()
for k in list(env):
 if k.startswith('AGENTSYNC_'): del env[k]
env.update(PYTHONPATH=str(repo/'src'),PYTHONDONTWRITEBYTECODE='1',TEMP=str(out),TMP=str(out))
xml=out/'junit.xml'; command=[r'D:\agentsync-debug\venv\Scripts\python.exe','-m','pytest','-q','tests','--junitxml',str(xml),'--basetemp',str(out/'test-tmp'),'-o','cache_dir='+str(out/'cache')]
result={'commit':commit,'scope':'full local Windows source suite; existing debug dependency environment','runtime_modules':modules,'status':'RUNNING','formal_release':'BLOCKED','real_clients':'NOT RUN'}
def save():(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
save();print(out,flush=True)
with (out/'pytest.log').open('wb') as log:
 p=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 try: code=p.wait(timeout=600)
 except subprocess.TimeoutExpired: p.terminate();p.wait(timeout=30);code=None
result['exit_status']=code; result['source_unchanged']=all(sha(repo/'src'/n)==h for n,h in modules.items())
if xml.exists():
 cases=ET.parse(xml).getroot().findall('.//testcase'); result['junit']={'tests':len(cases),'passed':sum(not any(c.find(t)is not None for t in ('failure','error','skipped'))for c in cases),'failed':sum(c.find('failure')is not None for c in cases),'errors':sum(c.find('error')is not None for c in cases),'skipped':sum(c.find('skipped')is not None for c in cases)}; result['junit_sha256']=sha(xml)
result['passed']=code==0 and result['source_unchanged'] and bool(result.get('junit'))
result['status']='COMPLETED' if code is not None else 'TIMED OUT / NOT COMPLETED';save();print(json.dumps(result['junit'] if 'junit' in result else result),flush=True)
raise SystemExit(0 if result['passed'] else 1)
