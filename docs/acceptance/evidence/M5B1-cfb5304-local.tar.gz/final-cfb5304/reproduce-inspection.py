import hashlib,json,subprocess,tarfile,zipfile,io,runpy,shutil,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('D:/agentsync-debug/evidence/final-cfb5304')
REPO=Path('F:/syuc/agentsync-verifier')
SHA='cfb5304c3979fc1677c73618120c0d33f928018a'
TREE='5e8580769ead8be5a6b4a21ee269aa0a0da01be6'
run=next((ROOT/'collector').glob('release-*'))
report=json.loads((run/'report.json').read_text())
assert report['commit_sha']==SHA and report['tree_sha']==TREE
assert not report['working_tree_status'] and not report['source_changed_during_execution']
assert len(report['checks'])==18 and all(x['status']=='pass' for x in report['checks'])
for item in report['artifacts']:
    path=run/item['path']
    assert path.resolve().is_relative_to(run.resolve()) and path.is_file()
    assert path.stat().st_size==item['size']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],item['path']
    assert not path.is_symlink()
for check in report['checks']:
    if 'log' in check:
        assert hashlib.sha256((run/check['log']).read_bytes()).hexdigest()==check['log_sha256']
    if 'junit' in check:
        assert check['junit']==dict(tests=757,failures=0,errors=0,skipped=3),check['junit']
module=subprocess.run(['git','show',SHA+':src/agentsync/verification/docker.py'],cwd=REPO,check=True,capture_output=True).stdout
module_sha=hashlib.sha256(module).hexdigest()
wheel=next((run/'artifacts').glob('*.whl'))
sdist=next((run/'artifacts').glob('*.tar.gz'))
with zipfile.ZipFile(wheel) as archive:
    assert hashlib.sha256(archive.read('agentsync/verification/docker.py')).hexdigest()==module_sha
with tarfile.open(sdist) as archive:
    name=next(n for n in archive.getnames() if n.endswith('/src/agentsync/verification/docker.py'))
    assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==module_sha
observations=[]
for folder in sorted((ROOT/'docker').iterdir()):
    files=list(folder.glob('*.json'))
    assert len(files)==14
    for file in files:
        result=json.loads(file.read_text())
        assert result['test_environment_id']==folder.name
        assert result['backend']=='local-linux-docker' and result['provenance']=='docker_black_box'
        assert result['execution_started'] is True and result['cleanup_confirmed'] is True
        assert result['constraints_verified'] is True and all(result['isolation']['checks'].values())
        assert result['verifier_source_sha256']==module_sha
        assert result['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
        assert result['status'] in {'passed','failed'}
        observations.append({'file':str(file.relative_to(ROOT)),'status':result['status'],'code':result['error_code'],'container_id':result['container_id']})
assert len(observations)==42 and len({x['container_id'] for x in observations})==42
cleanup=json.loads((ROOT/'cleanup-inspection.json').read_text())
assert cleanup['inspected']==42 and cleanup['all_exact_container_ids_absent'] is True
for name in ('junit.xml','wheel-junit.xml','sdist-junit.xml'):
    cases=list(ET.parse(run/name).iter('testcase'))
    actual=[case for case in cases if 'test_docker_verifier' in case.get('classname','')]
    assert len(actual)==14 and all(case.find('skipped') is None and case.find('failure') is None and case.find('error') is None for case in actual)
window=Path('D:/agentsync-debug/evidence/windows-cfb5304-junit.xml')
cases=list(ET.parse(window).iter('testcase'))
assert len(cases)==757 and sum(c.find('skipped') is not None for c in cases)==17
assert all(c.find('failure') is None and c.find('error') is None for c in cases)
helper=runpy.run_path(str(REPO/'tools/release_acceptance.py'))
helper['persist_junit'](window,ROOT/'windows-junit.xml')
safe,count=helper['redact_credentials'](Path('D:/agentsync-debug/evidence/windows-cfb5304-pytest.log').read_text(encoding='utf-8-sig'))
(ROOT/'windows-pytest.log').write_bytes(safe.replace('\r\n','\n').encode())
summary={'schema_version':1,'tested_commit_sha':SHA,'tested_tree_sha':TREE,'verifier_source_sha256':module_sha,'local_only':True,'github_execution_used':False,'checks_passed':18,'linux':{'source':{'passed':754,'skipped':3},'wheel':{'passed':754,'skipped':3},'sdist':{'passed':754,'skipped':3}},'windows':{'source':{'passed':740,'skipped':17}},'real_docker':{'environment_count':3,'observations':42,'tests_per_environment':14,'execution_started':42,'cleanup_confirmed':42,'independent_exact_id_absence_checks':42},'formal_release':'blocked','limitations':['M5B1 fixed standalone profile only; no arbitrary project tests.','No durable worker recovery, approval consumption or safe source apply.','Native development delegation is not an AgentSync client adapter test.','Real autonomous relay and remaining M6-M9 gates are unverified.'],'inspected_artifact_count':len(report['artifacts']),'observations':observations}
(ROOT/'inspection.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in summary.items() if k!='observations'},indent=2))
