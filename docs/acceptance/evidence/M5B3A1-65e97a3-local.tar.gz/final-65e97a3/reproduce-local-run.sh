set -eu
sha=65e97a3185a68b350aead0d364e69ced73df98f4
root=/root/final-65e97a3
mkdir -p /root/evidence/final-65e97a3
if [ ! -d "$root" ]; then git clone /root/source-binding.bundle "$root"; fi
cd "$root"
git checkout --detach "$sha"
test "$(git rev-parse HEAD)" = "$sha"
test -z "$(git status --porcelain)"
/root/jobs-env/bin/python -m pip install --no-deps -e .
export AGENTSYNC_DOCKER_TEST_IMAGE=sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
export AGENTSYNC_REQUIRE_DOCKER_TESTS=1
export AGENTSYNC_VERIFIER_EVIDENCE_DIR=/root/evidence/final-65e97a3/docker
export AGENTSYNC_OWNER_EXECUTOR_EVIDENCE_DIR=/root/evidence/final-65e97a3/owner-executor
export AGENTSYNC_RECONCILIATION_EVIDENCE_DIR=/root/evidence/final-65e97a3/reconciliation
export AGENTSYNC_BINDING_EVIDENCE_DIR=/root/evidence/final-65e97a3/candidate-binding
/root/jobs-env/bin/python tools/release_acceptance.py --output /root/evidence/final-65e97a3/collector --run --package-install --sdist-install
