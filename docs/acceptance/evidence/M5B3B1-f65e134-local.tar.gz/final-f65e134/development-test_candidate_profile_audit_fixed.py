from test_candidate_export import prepared as prepared, world as world
from agentsync.verification.candidate_jobs import CandidateVerificationJobs
from agentsync.verification.docker import DockerProfile, JsonCase
from agentsync.storage.database import connect
from agentsync.errors import AgentSyncError
import pytest

@pytest.mark.parametrize('column,changed',[('profile_sha256','f'*64),('image_id','sha256:'+'f'*64)])
def test_fixed_profile_column_change_rejected(prepared,column,changed):
    core,args,*_=prepared
    jobs=CandidateVerificationJobs(core)
    owner={k:args[k] for k in ('project_id','admin_token')}
    profile=DockerProfile('sha256:'+'b'*64,(JsonCase(None,True),))
    original=jobs.enqueue(**args,profile=profile,request_id='audit-enqueue')
    assert original[column]!=changed
    with connect(core.db_path) as db:
        db.execute('UPDATE candidate_verification_jobs SET '+column+'=? WHERE id=?',(changed,original['id']))
    for operation in (
        lambda:jobs.get(**owner,job_id=original['id']),
        lambda:jobs.list(**owner),
        lambda:jobs.cancel(**owner,job_id=original['id'],expected_version=1,request_id='audit-cancel'),
        lambda:jobs.enqueue(**args,profile=profile,request_id='audit-enqueue'),
    ):
        with pytest.raises(AgentSyncError) as exc:
            operation()
        assert exc.value.code=='corrupt_candidate_queue'
    with connect(core.db_path) as db:
        assert db.execute('SELECT status FROM candidate_verification_jobs WHERE id=?',(original['id'],)).fetchone()[0]=='queued'
        assert db.execute("SELECT count(*) FROM candidate_verification_requests WHERE operation='cancel'").fetchone()[0]==0

def test_fixed_corrupt_profile_timeout_overflow_normalized(prepared):
    core,args,*_=prepared
    profile=DockerProfile('sha256:'+'b'*64,(JsonCase(None,True),))
    object.__setattr__(profile,'timeout_seconds',10**400)
    with pytest.raises(AgentSyncError) as exc:
        CandidateVerificationJobs(core).enqueue(**args,profile=profile,request_id='audit-timeout-overflow')
    assert exc.value.code=='invalid_profile'
