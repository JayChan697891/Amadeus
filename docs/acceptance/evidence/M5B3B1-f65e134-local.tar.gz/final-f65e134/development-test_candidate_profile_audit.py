from test_candidate_export import prepared as prepared, world as world
from agentsync.verification.candidate_jobs import CandidateVerificationJobs
from agentsync.verification.docker import DockerProfile, JsonCase
from agentsync.storage.database import connect
import pytest

@pytest.mark.parametrize('column,changed',[('profile_sha256','f'*64),('image_id','sha256:'+'f'*64)])
def test_reproduce_profile_column_change_accepted(prepared,column,changed):
    core,args,*_=prepared
    jobs=CandidateVerificationJobs(core)
    owner={k:args[k] for k in ('project_id','admin_token')}
    original=jobs.enqueue(**args,profile=DockerProfile('sha256:'+'b'*64,(JsonCase(None,True),)),request_id='audit-enqueue')
    assert original[column]!=changed
    with connect(core.db_path) as db:
        db.execute('UPDATE candidate_verification_jobs SET '+column+'=? WHERE id=?',(changed,original['id']))
    current=jobs.get(**owner,job_id=original['id'])
    assert current[column]==changed
    cancelled=jobs.cancel(**owner,job_id=original['id'],expected_version=1,request_id='audit-cancel')
    assert cancelled[column]==changed and cancelled['status']=='cancelled'
def test_reproduce_corrupt_profile_timeout_overflow_unmapped(prepared):
    core,args,*_=prepared
    profile=DockerProfile('sha256:'+'b'*64,(JsonCase(None,True),))
    object.__setattr__(profile,'timeout_seconds',10**400)
    with pytest.raises(OverflowError):
        CandidateVerificationJobs(core).enqueue(**args,profile=profile,request_id='audit-timeout-overflow')
