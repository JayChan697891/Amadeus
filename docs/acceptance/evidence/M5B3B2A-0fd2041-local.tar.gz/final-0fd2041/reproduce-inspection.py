from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile,xml.etree.ElementTree as ET,runpy

ROOT=Path('D:/agentsync-debug/evidence/final-0fd2041')
REPO=Path('F:/syuc/agentsync-candidate-claim')
SHA='0fd2041c8efd1c4fa348117e013c0c5b1f30e470'
TREE='9a76e8c5280c34d38087f42fc35b702808d15c59'
run=next((ROOT/'collector').glob('release-*'))
report=json.loads((run/'report.json').read_text(encoding='utf-8'))
assert report['commit_sha']==SHA and report['tree_sha']==TREE
assert not report['working_tree_status'] and not report['source_changed_during_execution']
assert len(report['checks'])==18 and all(c['status']=='pass' for c in report['checks'])
for item in report['artifacts']:
 p=run/item['path'];assert p.resolve().is_relative_to(run.resolve()) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==item['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
for check in report['checks']:
 if 'log' in check: assert hashlib.sha256((run/check['log']).read_bytes()).hexdigest()==check['log_sha256']
 if 'junit' in check: assert check['junit']==dict(tests=1061,failures=0,errors=0,skipped=3)
modules={}
with zipfile.ZipFile(next((run/'artifacts').glob('*.whl'))) as wheel,tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as sdist:
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',SHA,'src/agentsync'],cwd=REPO).decode().splitlines()
 for name in (p.removeprefix('src/agentsync/') for p in paths if p.endswith('.py')):
  raw=subprocess.check_output(['git','show',SHA+':src/agentsync/'+name],cwd=REPO)
  digest=hashlib.sha256(raw).hexdigest()
  assert hashlib.sha256(wheel.read('agentsync/'+name)).hexdigest()==digest
  member=next(m for m in sdist.getmembers() if m.name.endswith('/src/agentsync/'+name))
  assert hashlib.sha256(sdist.extractfile(member).read()).hexdigest()==digest
  modules[name]=digest
with tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as distribution:
 name='tests/integration/test_binding_transaction.py'
 member=next(m for m in distribution.getmembers() if m.name.endswith('/'+name))
 assert distribution.extractfile(member).read()==subprocess.check_output(['git','show',SHA+':'+name],cwd=REPO)
observations=[]
for folder in (ROOT/'docker').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==14
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));assert data['test_environment_id']==folder.name
  assert data['execution_started'] and data['cleanup_confirmed'] and data['constraints_verified'] and all(data['isolation']['checks'].values())
  assert data['verifier_source_sha256']==modules['verification/docker.py']
  assert data['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  observations.append({'kind':'backend','container_id':data['container_id'],'file':str(file.relative_to(ROOT))})
for folder in (ROOT/'owner-executor').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==7
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));b=data['binding'];v=data['result'];e=data['execution']
  encoded=json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
  assert hashlib.sha256(encoded).hexdigest()==b['result_sha256']
  for key in ('input_sha256','source_sha256','commit_sha','tree_sha','profile_sha256'): assert b[key]==v[key]
  assert b['image_id']==v['image_sha256']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258' and b['container_id']==v['container_id']
  assert v['verifier_source_sha256']==modules['verification/docker.py']
  if e['assessment']=='unverified': assert v['observation_only'] is True and not e['cleanup_confirmed']
  else: assert e['phase']=='finished' and e['cleanup_confirmed']
  observations.append({'kind':'owner','container_id':b['container_id'],'file':str(file.relative_to(ROOT))})
receipts={}
for folder in (ROOT/'reconciliation').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==5
 counts={'removed_and_absent':0,'unresolved':0,'ineligible':0}
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));e=data['execution'];r=data['reconciliation']['reconciliation']
  assert data['test_environment_id']==folder.name
  assert data['injected_process_termination'] and data['injected_fixture_lease_expiry']
  assert e['assessment']=='unverified' and not e['cleanup_confirmed']
  assert e['result_sha256']==data['original_binding']['result_sha256']
  assert data['original_binding']['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  if file.name=='lost-create-ack.json':
   assert r is None and data['receipt_binding'] is None and not data['original_binding']['create_reply_complete']
   counts['ineligible']+=1
  else:
   assert r['status']=='recorded' and r['id']==data['receipt_binding']['id']
   assert data['original_binding']['create_reply_complete'] and data['original_binding']['container_id']==data['container_id']
   assert data['receipt_binding']['execution_id']==e['execution_id']
   encoded=json.dumps(data['observation'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
   assert hashlib.sha256(encoded).hexdigest()==r['observation_sha256']==data['receipt_binding']['observation_sha256']
   outcome=r['outcome'];assert outcome==data['observation']['outcome'];counts[outcome]+=1
   assert e['status']=='cleanup_pending' and e['phase']=='cleanup_pending'
   if file.name.startswith('hard-exit-'):
    assert outcome=='removed_and_absent'
    assert all(data['observation'][key] is True for key in ('identity_matched','remove_acknowledged','absence_observed','daemon_consistent'))
   else: assert outcome=='unresolved'
  if file.name=='hard-exit-running.json': assert data['actual_running_observed_before_kill']
  else: assert not data['actual_running_observed_before_kill']
  observations.append({'kind':'reconciliation','container_id':data['container_id'],'file':str(file.relative_to(ROOT))})
 assert counts=={'removed_and_absent':2,'unresolved':2,'ineligible':1}
 receipts[folder.name]=counts
assert len(observations)==78 and len({x['container_id'] for x in observations})==78
cleanup=json.loads((ROOT/'cleanup-inspection.json').read_text(encoding='utf-8'))
assert cleanup['inspected']==78 and cleanup['all_exact_container_ids_absent']
assert set(cleanup['container_ids'])=={x['container_id'] for x in observations}
for file in (ROOT/'reconciliation').glob('*/hard-exit-*.json'):
 assert json.loads(file.read_text(encoding='utf-8'))['observation']['daemon_identity_sha256']==cleanup['daemon_identity_sha256']
for name in ('junit.xml','wheel-junit.xml','sdist-junit.xml'):
 cases=list(ET.parse(run/name).iter('testcase'));assert len(cases)==1061
 actual=[c for c in cases if any(s in c.get('classname','') for s in ('test_docker_verifier','test_owner_execution','test_execution_reconciliation'))]
 assert len(actual)==26 and all(c.find('skipped') is None and c.find('failure') is None and c.find('error') is None for c in actual)
 new_unit=[c for c in cases if c.get('classname','').endswith('.test_candidate_binding')]
 new_git=[c for c in cases if c.get('classname','').endswith('.test_candidate_binding_git_records')]
 assert len(new_unit)==25 and len(new_git)==2 and all(c.find('skipped') is None for c in new_unit+new_git)
 cases_policy=[c for c in cases if 'test_verification_reconciliation' in c.get('classname','')]
 assert len(cases_policy)==43 and all(c.find('skipped') is None for c in cases_policy)
window=Path('D:/agentsync-debug/evidence/windows-0fd2041-junit.xml');cases=list(ET.parse(window).iter('testcase'))
assert len(cases)==1061 and sum(c.find('skipped') is not None for c in cases)==30
assert all(c.find('failure') is None and c.find('error') is None for c in cases)
helper=runpy.run_path(str(REPO/'tools/release_acceptance.py'))
helper['persist_junit'](window,ROOT/'windows-junit.xml')
safe,_=helper['redact_credentials'](Path('D:/agentsync-debug/evidence/windows-0fd2041-pytest.log').read_text(encoding='utf-8-sig'))
(ROOT/'windows-pytest.log').write_bytes(safe.replace('\r\n','\n').encode())
snapshot=Path('D:/agentsync-debug/evidence/windows-0fd2041-source-snapshot.json')
assert json.loads(snapshot.read_text(encoding='utf-8'))==json.loads((run/'source-snapshot.json').read_text(encoding='utf-8'))
(ROOT/'windows-source-snapshot.json').write_bytes(snapshot.read_bytes())

metadata=[]
for folder in (ROOT/'candidate-binding').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==2
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));p=data['provenance']
  assert data['environment_id']==folder.name and data['actual_git_setup'] is True
  assert data['filesystem_verified'] is False and data['execution_verified'] is False
  assert p['source_kind']=='managed_merge_candidate_metadata' and p['candidate_sha']!=p['base_sha']
  assert hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()==data['provenance_sha256']
  metadata.append({'file':str(file.relative_to(ROOT)),'provenance_sha256':data['provenance_sha256']})
assert len(metadata)==6


inputs=[]
for folder in (ROOT/'candidate-input').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==2
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));b=dict(data['binding']);binding_hash=b.pop('provenance_sha256');ip=data['input_provenance']
  assert data['environment_id']==folder.name and data['actual_git_object_export'] is True
  assert data['execution_verified'] is False and data['filesystem_atomicity_verified'] is False
  assert data['source_kind']=='managed_merge_candidate_input' and b['source_kind']=='managed_merge_candidate_metadata'
  assert hashlib.sha256(json.dumps({'schema':'agentsync.candidate-binding.v1',**b},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==binding_hash
  assert ip['binding_sha256']==binding_hash and ip['commit_sha']==b['candidate_sha']!=b['base_sha']
  assert hashlib.sha256(json.dumps(ip,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==data['input_provenance_sha256']
  source=b"def solve(x): return 'candidate'\n" if file.name=='merged-input.json' else b"def solve(x): return x\n"
  assert hashlib.sha256(source).hexdigest()==ip['source_sha256']==data['expected_literal_source_sha256']
  manifest=data['manifest'];assert [x[0] for x in manifest]==data['expected_fixture_manifest_paths']==['left.txt','right.txt','same.txt','solution.py']
  blob=next(x for x in manifest if x[0]=='solution.py');assert blob[2]==len(source)
  assert hashlib.new('sha1' if len(blob[1])==40 else 'sha256',b'blob '+str(len(source)).encode()+b'\0'+source).hexdigest()==blob[1]
  obj={'format':'agentsync-candidate-v1','commit_sha':ip['commit_sha'],'tree_sha':ip['tree_sha'],'manifest':manifest,'source_sha256':ip['source_sha256']}
  assert hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()==ip['input_sha256']
  assert data['parent_count']==(2 if file.name=='merged-input.json' else 1)
  inputs.append({'file':str(file.relative_to(ROOT)),'input_provenance_sha256':data['input_provenance_sha256']})
assert len(inputs)==6 and len(modules)==33
for name in ('junit.xml','wheel-junit.xml','sdist-junit.xml'):
 cases=list(ET.parse(run/name).iter('testcase'))
 new=[c for c in cases if c.get('classname','').endswith(('.test_candidate_export','.test_candidate_export_security'))]
 assert len(new)==41 and all(c.find('failure') is None and c.find('skipped') is None and c.find('error') is None for c in new)

summary={'schema_version':1,'tested_commit_sha':SHA,'tested_tree_sha':TREE,'module_sha256':modules,'checks_passed':18,'local_only':True,'github_execution_used':False,'linux':{k:{'passed':1058,'skipped':3} for k in ('source','wheel','sdist')},'windows':{'source':{'passed':1031,'skipped':30}},'real_observations':{'backend':42,'owner_executor':21,'reconciliation':15,'total':78,'independent_exact_id_absence_checks':78,'cleanup_receipts_by_environment':receipts},'formal_release':'blocked','limitations':['Explicit one-shot owner cleanup observations only; original assessment remains unverified.','Actual executor process termination and DB reopen; lease expiry is injected into disposable fixture data.','No retry/resume of interrupted cleanup intents, no unknown/late-create recovery or historical daemon identity proof.','No task acceptance gate, approval consumption, safe apply or real client relay.','Policy fault injection is separate from actual Docker evidence.'],'observations':observations,'metadata_binding_observations':metadata}
summary['scope']='M5B3B2A one-shot owner candidate reservation'
summary['candidate_input_observations']=inputs
summary['limitations']=['Owner reservation observations only; no worker/execution/task gate or apply.', 'Caller-constructible dataclass and unkeyed digest do not grant authority.', 'Existing Docker/owner/reconciliation tests are regression evidence only.', 'No task gate, approval consumption, safe apply, actual client relay or complete platform/M9 acceptance.']
for junit in [run/'junit.xml', run/'wheel-junit.xml', run/'sdist-junit.xml', ROOT/'windows-junit.xml']:
 cases=list(ET.parse(junit).iter('testcase'))
 new=[c for c in cases if c.get('classname','').endswith('.test_binding_transaction')]
 assert len(new)==7 and all(c.find('failure') is None and c.find('skipped') is None and c.find('error') is None for c in new)
assert len(json.loads((run/'source-snapshot.json').read_text(encoding='utf-8')))==253
summary['new_transaction_cases_per_environment']=7
summary['source_snapshot_files']=253
def canonical(value, ascii_only=False):
 return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=ascii_only,allow_nan=False)
def digest(value):return hashlib.sha256(value.encode()).hexdigest()
with tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as distribution:
 for name in ['tests/integration/test_candidate_jobs.py','tests/integration/test_candidate_queue_security.py','tests/unit/test_candidate_queue_migration.py']:
  member=next(m for m in distribution.getmembers() if m.name.endswith('/'+name))
  assert distribution.extractfile(member).read()==subprocess.check_output(['git','show',SHA+':'+name],cwd=REPO)
queue_observations=[]
for folder in (ROOT/'candidate-queue').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==2
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));row=data['stored_queue_row'];raw=row['metadata_json'];meta=json.loads(raw)
  assert raw==canonical(meta) and digest(raw)==row['metadata_sha256']
  b=dict(meta['binding']);receipts=b.pop('receipts');binding_hash=b.pop('provenance_sha256')
  assert digest(canonical({'schema':'agentsync.candidate-binding.v1',**b,'receipt_sha256':[digest(r) for r in receipts]}))==binding_hash==row['binding_sha256']
  snap=meta['snapshot'];source=b"def solve(x): return 'candidate'\n";source_hash=hashlib.sha256(source).hexdigest()
  assert snap['source_sha256']==source_hash==data['expected_literal_source_sha256']==row['source_sha256']
  assert snap['commit_sha']==b['candidate_sha']==row['candidate_sha']!=b['base_sha']
  for key in ['project_id','candidate_id','snapshot_id','left_worktree_id','right_worktree_id','left_task_id','right_task_id','left_task_version','right_task_version','base_sha','left_sha','right_sha']:assert row[key]==b[key]
  manifest=snap['manifest'];assert [v[0] for v in manifest]==['left.txt','right.txt','same.txt','solution.py']
  blob=next(v for v in manifest if v[0]=='solution.py');assert blob[2]==len(source)
  assert hashlib.new('sha1' if len(blob[1])==40 else 'sha256',b'blob '+str(len(source)).encode()+b'\0'+source).hexdigest()==blob[1]
  input_hash=digest(canonical({'format':'agentsync-candidate-v1',**{k:snap[k] for k in ['commit_sha','tree_sha','manifest','source_sha256']}},True))
  assert input_hash==snap['input_sha256']==row['input_sha256'] and snap['tree_sha']==row['tree_sha']
  provenance={'schema':'agentsync.candidate-input.v1','source_kind':'managed_merge_candidate_input','binding_sha256':binding_hash,**{k:snap[k] for k in ['commit_sha','tree_sha','input_sha256','source_sha256']}}
  assert digest(canonical(provenance))==meta['provenance_sha256']==row['provenance_sha256']
  profile=meta['verification_profile'];assert profile=={'kind':row['profile_kind'],'sha256':row['profile_sha256'],'image_id':row['image_id']}
  assert data['environment_id']==folder.name and data['actual_git_candidate_export'] is True and data['execution_verified'] is False and data['real_clients_verified'] is False
  historical=data['historical_receipt'];current=data['current'];cancel=data['historical_cancel_receipt']
  assert historical['status']=='queued' and historical['version']==1 and historical['receipt_kind']=='historical_enqueue' and historical['current_state'] is False
  assert current['current_state'] is True and current['status']==row['status'] and current['version']==row['version']
  for v in [historical,current]+([cancel] if cancel else []):
   assert v['execution_connected'] is False and v['execution_assessment']=='unverified'
   for k in ['id','project_id','candidate_id','snapshot_id','candidate_sha','tree_sha','input_sha256','source_sha256','binding_sha256','provenance_sha256','metadata_sha256','profile_kind','profile_sha256','image_id','source_kind','created_at']:assert v[k]==row[k]
  if cancel:
   assert row['status']=='cancelled' and row['version']==2 and cancel['current_state'] is False and cancel['receipt_kind']=='historical_cancel' and cancel['version']==2
  else:assert row['status']=='queued' and row['version']==1
  requests=data['stored_request_rows'];assert len(requests)==(2 if cancel else 1)
  for request in requests:
   expected=historical if request['operation']=='enqueue' else cancel;assert expected is not None
   assert request['response_json']==canonical(expected) and digest(request['response_json'])==request['response_sha256']
   payload={'schema':'agentsync.candidate-request.v1','operation':request['operation']}
   if request['operation']=='enqueue':payload.update(candidate_id=row['candidate_id'],expected_candidate_sha=row['candidate_sha'],profile_kind=row['profile_kind'],profile_sha256=row['profile_sha256'],image_id=row['image_id'])
   else:payload.update(job_id=row['id'],expected_version=1)
   assert digest(canonical(payload))==request['payload_hash'] and request['job_id']==row['id'] and request['project_id']==row['project_id']
  queue_observations.append({'file':str(file.relative_to(ROOT)),'metadata_sha256':row['metadata_sha256'],'state':row['status'],'requests_verified':len(requests)})
assert len(queue_observations)==6
for junit in [run/'junit.xml',run/'wheel-junit.xml',run/'sdist-junit.xml',ROOT/'windows-junit.xml']:
 cases=list(ET.parse(junit).iter('testcase'))
 for suffix,count in [('.test_candidate_jobs',40),('.test_candidate_queue_security',6),('.test_candidate_queue_migration',4)]:
  selected=[c for c in cases if c.get('classname','').endswith(suffix)]
  assert len(selected)==count and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in selected),(str(junit),suffix,len(selected))
summary['candidate_queue_observations']=queue_observations
summary['new_queue_cases_per_environment']=50


claim_observations=[]
claim_pins=['metadata_sha256','profile_kind','profile_sha256','image_id','candidate_sha','tree_sha','input_sha256','source_sha256']
proof_fields={'schema','id','project_id','job_id','kind','claim_version',*claim_pins,'created_at','lease_expires_at'}
for folder in (ROOT/'candidate-claim').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==2
 for file in files:
  data=json.loads(file.read_text(encoding='utf-8'));job=data['queue_row'];claim=data['claim_row'];proof=json.loads(claim['proof_json']);meta=json.loads(job['metadata_json'])
  assert data['environment_id']==folder.name and data['actual_git_object_export'] is True
  assert all(data[k] is False for k in ['execution_verified','real_clients_verified','worker_credential_issued','cleanup_performed'])
  assert digest(canonical(meta))==job['metadata_sha256'] and canonical(meta)==job['metadata_json']
  b=dict(meta['binding']);receipts=b.pop('receipts');binding_hash=b.pop('provenance_sha256')
  assert digest(canonical({'schema':'agentsync.candidate-binding.v1',**b,'receipt_sha256':[digest(r) for r in receipts]}))==binding_hash==job['binding_sha256']
  snap=meta['snapshot'];literal=b"def solve(x): return 'candidate'\n"
  assert hashlib.sha256(literal).hexdigest()==snap['source_sha256']==job['source_sha256']==data['expected_candidate_source_sha256']
  assert snap['commit_sha']==b['candidate_sha']==job['candidate_sha']!=b['base_sha']
  manifest=snap['manifest'];assert [v[0] for v in manifest]==['left.txt','right.txt','same.txt','solution.py']
  blob=next(v for v in manifest if v[0]=='solution.py');assert blob[2]==len(literal)
  assert hashlib.new('sha1' if len(blob[1])==40 else 'sha256',b'blob '+str(len(literal)).encode()+b'\0'+literal).hexdigest()==blob[1]
  assert digest(canonical({'format':'agentsync-candidate-v1',**{k:snap[k] for k in ['commit_sha','tree_sha','manifest','source_sha256']}},True))==job['input_sha256']==snap['input_sha256']
  assert digest(canonical({'schema':'agentsync.candidate-input.v1','source_kind':'managed_merge_candidate_input','binding_sha256':binding_hash,**{k:snap[k] for k in ['commit_sha','tree_sha','input_sha256','source_sha256']}}))==meta['provenance_sha256']==job['provenance_sha256']
  assert meta['verification_profile']=={'kind':job['profile_kind'],'sha256':job['profile_sha256'],'image_id':job['image_id']}
  assert set(proof)==proof_fields and proof['schema']=='agentsync.candidate-claim.v1'
  assert type(proof['claim_version']) is int and proof['claim_version']==2 and proof['kind']=='owner_reservation_v1'
  assert len(claim['proof_json'].encode())<=16384 and canonical(proof)==claim['proof_json'] and digest(claim['proof_json'])==claim['proof_sha256']
  for k in proof_fields-{'schema'}:assert proof[k]==claim[k],k
  for k in claim_pins:assert claim[k]==job[k],k
  assert proof['job_id']==job['id'] and proof['project_id']==job['project_id']
  assert proof['created_at']>=job['created_at'] and proof['lease_expires_at']-proof['created_at']==300
  enqueue=data['enqueue_receipt'];original=data['claim_receipt'];recovery=data['recovery_receipt'];current=data['current_view']
  assert enqueue['status']=='queued' and enqueue['version']==1 and enqueue['receipt_kind']=='historical_enqueue' and enqueue['current_state'] is False
  assert original['schema']=='agentsync.candidate-claim-receipt.v1' and original['receipt_kind']=='historical_claim'
  assert original['job']['status']=='claimed' and original['job']['version']==2 and original['reservation']['status']=='claimed'
  assert original['reservation']['reason_code']=='' and original['reservation']['proof_sha256']==claim['proof_sha256']
  assert original['reservation']['updated_at']==proof['created_at'] and original['job']['updated_at']==proof['created_at']
  assert current['current_state'] is True and current['job']['status']==job['status'] and current['job']['version']==job['version']
  assert current['reservation']['status']==claim['status'] and current['reservation']['proof_sha256']==claim['proof_sha256']
  assert current['reservation']['clock_regressed'] is False and current['reservation']['lease_expired'] is False
  for receipt in [original]+([recovery] if recovery else []):
   for obj in [receipt,receipt['job'],receipt['reservation']]:
    assert obj['current_state'] is False and obj['execution_connected'] is False and obj['execution_assessment']=='unverified'
   assert 'clock_regressed' not in receipt['reservation'] and 'lease_expired' not in receipt['reservation']
   assert len(canonical(receipt).encode())<=16384
  if recovery:
   assert job['status']=='interrupted' and job['version']==3 and claim['status']=='interrupted' and claim['reason_code']=='owner_interrupted'
   assert recovery['schema']=='agentsync.candidate-recovery.v1' and recovery['receipt_kind']=='historical_recovery' and recovery['reason_code']=='owner_interrupted'
   assert recovery['job']==current['job']|{'current_state':False}
   assert len(data['recovery_rows'])==1
   request=data['recovery_rows'][0];assert request['claim_id']==claim['id'] and request['job_id']==job['id'] and request['project_id']==job['project_id']
   assert request['response_json']==canonical(recovery) and digest(request['response_json'])==request['response_sha256']
   assert digest(canonical({'schema':'agentsync.candidate-claim-recovery-request.v1','project_id':job['project_id'],'job_id':job['id'],'claim_id':claim['id'],'expected_version':2}))==request['payload_hash']
  else:assert job['status']=='claimed' and job['version']==2 and claim['status']=='claimed' and not data['recovery_rows']
  claim_observations.append({'file':str(file.relative_to(ROOT)),'proof_sha256':claim['proof_sha256'],'status':claim['status'],'recovery_requests_verified':len(data['recovery_rows'])})
assert len(claim_observations)==6
for junit in [run/'junit.xml',run/'wheel-junit.xml',run/'sdist-junit.xml',ROOT/'windows-junit.xml']:
 cases=list(ET.parse(junit).iter('testcase'))
 for suffix,count in [('.test_candidate_claims',34),('.test_candidate_claim_migration',4)]:
  selected=[c for c in cases if c.get('classname','').endswith(suffix)]
  assert len(selected)==count and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in selected),(str(junit),suffix,len(selected))
with tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as distribution:
 for name in ['tests/integration/test_candidate_claims.py','tests/integration/test_candidate_claim_migration.py']:
  member=next(m for m in distribution.getmembers() if m.name.endswith('/'+name))
  assert distribution.extractfile(member).read()==subprocess.check_output(['git','show',SHA+':'+name],cwd=REPO)
summary['candidate_claim_observations']=claim_observations
summary['new_claim_cases_per_environment']=34+4

(ROOT/'inspection.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in summary.items() if k!='observations'},indent=2))
