import json, hashlib
import pytest
from test_candidate_export import prepared as prepared, world as world
from test_candidate_jobs import enqueue, owner, profile
from agentsync.verification.candidate_jobs import CandidateVerificationJobs
from agentsync.verification.candidate_claims import OwnerCandidateClaims
from agentsync.storage.database import connect
from agentsync.errors import AgentSyncError

@pytest.mark.parametrize('mutation',['deadline-column','proof-float-version'])
def test_fault_injected_claim_consistency_rejected_on_every_owner_read(prepared,mutation):
    original=enqueue(prepared)
    claims=OwnerCandidateClaims(prepared[0]); jobs=CandidateVerificationJobs(prepared[0])
    args=owner(prepared); jid=original['id']
    reservation=claims.claim_once(**args,job_id=jid,expected_version=1,profile=profile())
    assert claims.get(**args,job_id=jid)['job']['status']=='claimed'
    assert enqueue(prepared)==original
    with connect(prepared[0].db_path) as db:
        if mutation=='deadline-column':
            db.execute('UPDATE candidate_verification_claims SET lease_expires_at=lease_expires_at+1 WHERE job_id=?',(jid,))
        else:
            proof=json.loads(db.execute('SELECT proof_json FROM candidate_verification_claims WHERE job_id=?',(jid,)).fetchone()[0])
            proof['claim_version']=2.0
            raw=json.dumps(proof,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
            db.execute('UPDATE candidate_verification_claims SET proof_json=?,proof_sha256=? WHERE job_id=?',(raw,hashlib.sha256(raw.encode()).hexdigest(),jid))
    operations=(lambda:claims.get(**args,job_id=jid),lambda:jobs.get(**args,job_id=jid),lambda:jobs.list(**args),lambda:enqueue(prepared),lambda:claims.recover_interrupted(**args,job_id=jid,expected_version=2,request_id='audit-recover'))
    for operation in operations:
        with pytest.raises(AgentSyncError) as exc: operation()
        assert exc.value.code=='corrupt_candidate_queue'
    with connect(prepared[0].db_path) as db:
        assert db.execute('SELECT count(*) FROM candidate_claim_recoveries').fetchone()[0]==0
