set -eu
docker info --format '{{.ServerVersion}}'
docker image inspect --format '{{.Id}}' sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
sha=0fd2041c8efd1c4fa348117e013c0c5b1f30e470
root=/root/final-0fd2041
mkdir -p /root/evidence/final-0fd2041
if [ ! -d "$root" ]; then git clone /root/source-candidate-claim.bundle "$root"; fi
cd "$root"
git checkout --detach "$sha"
test "$(git rev-parse HEAD)" = "$sha"
test -z "$(git status --porcelain)"
/root/jobs-env/bin/python -m pip install --no-deps -e .
export AGENTSYNC_DOCKER_TEST_IMAGE=sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
export AGENTSYNC_REQUIRE_DOCKER_TESTS=1
export AGENTSYNC_VERIFIER_EVIDENCE_DIR=/root/evidence/final-0fd2041/docker
export AGENTSYNC_OWNER_EXECUTOR_EVIDENCE_DIR=/root/evidence/final-0fd2041/owner-executor
export AGENTSYNC_RECONCILIATION_EVIDENCE_DIR=/root/evidence/final-0fd2041/reconciliation
export AGENTSYNC_BINDING_EVIDENCE_DIR=/root/evidence/final-0fd2041/candidate-binding
export AGENTSYNC_CANDIDATE_INPUT_EVIDENCE_DIR=/root/evidence/final-0fd2041/candidate-input
export AGENTSYNC_CANDIDATE_QUEUE_EVIDENCE_DIR=/root/evidence/final-0fd2041/candidate-queue
export AGENTSYNC_CANDIDATE_CLAIM_EVIDENCE_DIR=/root/evidence/final-0fd2041/candidate-claim
/root/jobs-env/bin/python tools/release_acceptance.py --output /root/evidence/final-0fd2041/collector --run --package-install --sdist-install
