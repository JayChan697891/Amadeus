set -eu
docker info --format '{{.ServerVersion}}'
docker image inspect --format '{{.Id}}' sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
sha=2ed3607de761f731ce8f80385af86260e126a4f4
root=/root/final-2ed3607
mkdir -p /root/evidence/final-2ed3607
if [ ! -d "$root" ]; then git clone /root/source-candidate-export.bundle "$root"; fi
cd "$root"
git checkout --detach "$sha"
test "$(git rev-parse HEAD)" = "$sha"
test -z "$(git status --porcelain)"
/root/jobs-env/bin/python -m pip install --no-deps -e .
export AGENTSYNC_DOCKER_TEST_IMAGE=sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
export AGENTSYNC_REQUIRE_DOCKER_TESTS=1
export AGENTSYNC_VERIFIER_EVIDENCE_DIR=/root/evidence/final-2ed3607/docker
export AGENTSYNC_OWNER_EXECUTOR_EVIDENCE_DIR=/root/evidence/final-2ed3607/owner-executor
export AGENTSYNC_RECONCILIATION_EVIDENCE_DIR=/root/evidence/final-2ed3607/reconciliation
export AGENTSYNC_BINDING_EVIDENCE_DIR=/root/evidence/final-2ed3607/candidate-binding
export AGENTSYNC_CANDIDATE_INPUT_EVIDENCE_DIR=/root/evidence/final-2ed3607/candidate-input
/root/jobs-env/bin/python tools/release_acceptance.py --output /root/evidence/final-2ed3607/collector --run --package-install --sdist-install
