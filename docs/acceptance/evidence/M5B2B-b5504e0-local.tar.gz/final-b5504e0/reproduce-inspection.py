from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile,xml.etree.ElementTree as ET,runpy
ROOT=Path('D:/agentsync-debug/evidence/final-b5504e0');REPO=Path('F:/syuc/agentsync-executor')
SHA='b5504e09bf1cb1c390d56cac11e68a8176d2091d';TREE='4b0fdcba6ed826870ec19c8382ccbf7064108550'
run=next((ROOT/'collector').glob('release-*'));report=json.loads((run/'report.json').read_text())
assert report['commit_sha']==SHA and report['tree_sha']==TREE and not report['working_tree_status'] and not report['source_changed_during_execution']
assert len(report['checks'])==18 and all(c['status']=='pass' for c in report['checks'])
for item in report['artifacts']:
 p=run/item['path'];assert p.resolve().is_relative_to(run.resolve()) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==item['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
for check in report['checks']:
 if 'log' in check:assert hashlib.sha256((run/check['log']).read_bytes()).hexdigest()==check['log_sha256']
 if 'junit' in check:assert check['junit']==dict(tests=850,failures=0,errors=0,skipped=3)
modules={}
with zipfile.ZipFile(next((run/'artifacts').glob('*.whl'))) as wheel,tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as sdist:
 for name in ('verification/docker.py','verification/executor.py','verification/jobs.py','storage/database.py','core/permissions.py'):
  raw=subprocess.run(['git','show',SHA+':src/agentsync/'+name],cwd=REPO,capture_output=True,check=True).stdout
  digest=hashlib.sha256(raw).hexdigest();assert hashlib.sha256(wheel.read('agentsync/'+name)).hexdigest()==digest
  member=next(m for m in sdist.getmembers() if m.name.endswith('/src/agentsync/'+name));assert hashlib.sha256(sdist.extractfile(member).read()).hexdigest()==digest
  modules[name]=digest
observations=[]
for folder in (ROOT/'docker').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==14
 for file in files:
  r=json.loads(file.read_text());assert r['test_environment_id']==folder.name
  assert r['execution_started'] and r['cleanup_confirmed'] and r['constraints_verified'] and all(r['isolation']['checks'].values())
  assert r['verifier_source_sha256']==modules['verification/docker.py']
  assert r['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  observations.append({'file':str(file.relative_to(ROOT)),'container_id':r['container_id'],'kind':'backend','assessment':r['status']})
assert len(observations)==42
owner_summaries={}
for folder in (ROOT/'owner-executor').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==7
 counts={}
 for file in files:
  r=json.loads(file.read_text());e=r['execution'];b=r['binding'];v=r['result']
  assert r['test_environment_id']==folder.name and v['provenance']=='docker_black_box' and v['backend']=='local-linux-docker'
  assert v['verifier_source_sha256']==modules['verification/docker.py'] and v['cleanup_confirmed'] and all(v['isolation']['checks'].values())
  assert v['container_id']==b['container_id'] and v['commit_sha']==b['commit_sha'] and v['tree_sha']==b['tree_sha']
  for key in ('source_sha256','input_sha256','profile_sha256'):assert v[key]==b[key]
  assert v['image_sha256']==b['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  digest=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
  assert digest==b['result_sha256']==e['result_sha256']
  assessment=e['assessment'];counts[assessment]=counts.get(assessment,0)+1
  if file.name=='fixed-snapshot.json':assert assessment=='passed' and v['passed_case_count']==2
  elif file.name=='wall-time.json':assert assessment=='failed' and v['errors'][0]=='timeout'
  elif file.name=='owner-cancel-before-start.json':assert assessment=='cancelled' and not v['execution_started'] and not e['execution_started']
  elif file.name=='expired-lease-after-real-pass.json':assert assessment=='unverified' and v['status']=='passed' and e['execution_started']
  else:assert file.name.startswith('test_actual_owner_rejects_candidate_self_report[') and assessment=='failed'
  if assessment=='unverified':assert e['phase']=='cleanup_pending' and not e['cleanup_confirmed'] and v.get('observation_only') is True and v['status']=='passed'
  else:assert e['phase']=='finished' and e['cleanup_confirmed']
  observations.append({'file':str(file.relative_to(ROOT)),'container_id':b['container_id'],'kind':'owner_execution','assessment':assessment,'backend_status':v['status']})
 assert counts=={'passed':1,'failed':4,'cancelled':1,'unverified':1},counts
 owner_summaries[folder.name]=counts
assert len(observations)==63 and len({x['container_id'] for x in observations})==63
cleanup=json.loads((ROOT/'cleanup-inspection.json').read_text());assert cleanup['inspected']==63 and cleanup['all_exact_container_ids_absent'] is True
for name in ('junit.xml','wheel-junit.xml','sdist-junit.xml'):
 cases=list(ET.parse(run/name).iter('testcase'));assert len(cases)==850
 actual=[c for c in cases if 'test_docker_verifier' in c.get('classname','') or 'test_owner_execution' in c.get('classname','')]
 assert len(actual)==21 and all(c.find('skipped') is None and c.find('failure') is None and c.find('error') is None for c in actual)
window=Path('D:/agentsync-debug/evidence/windows-b5504e0-junit.xml');cases=list(ET.parse(window).iter('testcase'))
assert len(cases)==850 and sum(c.find('skipped') is not None for c in cases)==24 and all(c.find('failure') is None and c.find('error') is None for c in cases)
helper=runpy.run_path(str(REPO/'tools/release_acceptance.py'));helper['persist_junit'](window,ROOT/'windows-junit.xml')
safe,_=helper['redact_credentials'](Path('D:/agentsync-debug/evidence/windows-b5504e0-pytest.log').read_text(encoding='utf-8-sig'))
(ROOT/'windows-pytest.log').write_bytes(safe.replace('\r\n','\n').encode())
summary={'schema_version':1,'tested_commit_sha':SHA,'tested_tree_sha':TREE,'module_sha256':modules,'local_only':True,'github_execution_used':False,'checks_passed':18,'linux':{name:{'passed':847,'skipped':3} for name in ('source','wheel','sdist')},'windows':{'source':{'passed':826,'skipped':24}},'real_observations':{'backend':42,'owner_executor':21,'total':63,'independent_exact_id_absence_checks':63,'owner_assessments_by_environment':owner_summaries},'formal_release':'blocked','limitations':['Fixed owner snapshot/finite standalone profile only.','No automatic crash/orphan reconciliation or retry; abrupt-process recovery is not claimed.','No task acceptance gate, approval consumption, safe apply or real client relay.','Simulated failure/clock/partial-create policy tests are separate from actual Docker observations.'],'observations':observations}
(ROOT/'inspection.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in summary.items() if k!='observations'},indent=2))
