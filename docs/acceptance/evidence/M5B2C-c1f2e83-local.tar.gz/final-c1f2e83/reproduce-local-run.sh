set -eu
sha=c1f2e83a61af5c267e3374dd46398b2a57b6abf1
root=/root/final-c1f2e83
mkdir -p /root/evidence/final-c1f2e83
if [ ! -d "$root" ]; then git clone /root/source-reconciliation.bundle "$root"; fi
cd "$root"
git checkout --detach "$sha"
test "$(git rev-parse HEAD)" = "$sha"
test -z "$(git status --porcelain)"
/root/jobs-env/bin/python -m pip install --no-deps -e .
export AGENTSYNC_DOCKER_TEST_IMAGE=sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
export AGENTSYNC_REQUIRE_DOCKER_TESTS=1
export AGENTSYNC_VERIFIER_EVIDENCE_DIR=/root/evidence/final-c1f2e83/docker
export AGENTSYNC_OWNER_EXECUTOR_EVIDENCE_DIR=/root/evidence/final-c1f2e83/owner-executor
export AGENTSYNC_RECONCILIATION_EVIDENCE_DIR=/root/evidence/final-c1f2e83/reconciliation
/root/jobs-env/bin/python tools/release_acceptance.py --output /root/evidence/final-c1f2e83/collector --run --package-install --sdist-install
