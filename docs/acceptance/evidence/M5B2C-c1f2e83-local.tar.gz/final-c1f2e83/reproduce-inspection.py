from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile,xml.etree.ElementTree as ET,runpy

ROOT=Path('D:/agentsync-debug/evidence/final-c1f2e83')
REPO=Path('F:/syuc/agentsync-reconciliation')
SHA='c1f2e83a61af5c267e3374dd46398b2a57b6abf1'
TREE='de68cde10628e48122fad14409983ccbab570802'
run=next((ROOT/'collector').glob('release-*'))
report=json.loads((run/'report.json').read_text())
assert report['commit_sha']==SHA and report['tree_sha']==TREE
assert not report['working_tree_status'] and not report['source_changed_during_execution']
assert len(report['checks'])==18 and all(c['status']=='pass' for c in report['checks'])
for item in report['artifacts']:
 p=run/item['path'];assert p.resolve().is_relative_to(run.resolve()) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==item['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
for check in report['checks']:
 if 'log' in check: assert hashlib.sha256((run/check['log']).read_bytes()).hexdigest()==check['log_sha256']
 if 'junit' in check: assert check['junit']==dict(tests=898,failures=0,errors=0,skipped=3)
modules={}
with zipfile.ZipFile(next((run/'artifacts').glob('*.whl'))) as wheel,tarfile.open(next((run/'artifacts').glob('*.tar.gz'))) as sdist:
 for name in ('verification/docker.py','verification/executor.py','verification/jobs.py','verification/reconciliation.py','storage/database.py','core/permissions.py'):
  raw=subprocess.check_output(['git','show',SHA+':src/agentsync/'+name],cwd=REPO)
  digest=hashlib.sha256(raw).hexdigest()
  assert hashlib.sha256(wheel.read('agentsync/'+name)).hexdigest()==digest
  member=next(m for m in sdist.getmembers() if m.name.endswith('/src/agentsync/'+name))
  assert hashlib.sha256(sdist.extractfile(member).read()).hexdigest()==digest
  modules[name]=digest
observations=[]
for folder in (ROOT/'docker').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==14
 for file in files:
  data=json.loads(file.read_text());assert data['test_environment_id']==folder.name
  assert data['execution_started'] and data['cleanup_confirmed'] and data['constraints_verified'] and all(data['isolation']['checks'].values())
  assert data['verifier_source_sha256']==modules['verification/docker.py']
  assert data['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  observations.append({'kind':'backend','container_id':data['container_id'],'file':str(file.relative_to(ROOT))})
for folder in (ROOT/'owner-executor').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==7
 for file in files:
  data=json.loads(file.read_text());b=data['binding'];v=data['result'];e=data['execution']
  encoded=json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
  assert hashlib.sha256(encoded).hexdigest()==b['result_sha256']
  for key in ('input_sha256','source_sha256','commit_sha','tree_sha','profile_sha256'): assert b[key]==v[key]
  assert b['image_id']==v['image_sha256']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258' and b['container_id']==v['container_id']
  assert v['verifier_source_sha256']==modules['verification/docker.py']
  if e['assessment']=='unverified': assert v['observation_only'] is True and not e['cleanup_confirmed']
  else: assert e['phase']=='finished' and e['cleanup_confirmed']
  observations.append({'kind':'owner','container_id':b['container_id'],'file':str(file.relative_to(ROOT))})
receipts={}
for folder in (ROOT/'reconciliation').iterdir():
 files=list(folder.glob('*.json'));assert len(files)==5
 counts={'removed_and_absent':0,'unresolved':0,'ineligible':0}
 for file in files:
  data=json.loads(file.read_text());e=data['execution'];r=data['reconciliation']['reconciliation']
  assert data['test_environment_id']==folder.name
  assert data['injected_process_termination'] and data['injected_fixture_lease_expiry']
  assert e['assessment']=='unverified' and not e['cleanup_confirmed']
  assert e['result_sha256']==data['original_binding']['result_sha256']
  assert data['original_binding']['image_id']=='sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258'
  if file.name=='lost-create-ack.json':
   assert r is None and data['receipt_binding'] is None and not data['original_binding']['create_reply_complete']
   counts['ineligible']+=1
  else:
   assert r['status']=='recorded' and r['id']==data['receipt_binding']['id']
   assert data['original_binding']['create_reply_complete'] and data['original_binding']['container_id']==data['container_id']
   assert data['receipt_binding']['execution_id']==e['execution_id']
   encoded=json.dumps(data['observation'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
   assert hashlib.sha256(encoded).hexdigest()==r['observation_sha256']==data['receipt_binding']['observation_sha256']
   outcome=r['outcome'];assert outcome==data['observation']['outcome'];counts[outcome]+=1
   assert e['status']=='cleanup_pending' and e['phase']=='cleanup_pending'
   if file.name.startswith('hard-exit-'):
    assert outcome=='removed_and_absent'
    assert all(data['observation'][key] is True for key in ('identity_matched','remove_acknowledged','absence_observed','daemon_consistent'))
   else: assert outcome=='unresolved'
  if file.name=='hard-exit-running.json': assert data['actual_running_observed_before_kill']
  else: assert not data['actual_running_observed_before_kill']
  observations.append({'kind':'reconciliation','container_id':data['container_id'],'file':str(file.relative_to(ROOT))})
 assert counts=={'removed_and_absent':2,'unresolved':2,'ineligible':1}
 receipts[folder.name]=counts
assert len(observations)==78 and len({x['container_id'] for x in observations})==78
cleanup=json.loads((ROOT/'cleanup-inspection.json').read_text())
assert cleanup['inspected']==78 and cleanup['all_exact_container_ids_absent']
assert set(cleanup['container_ids'])=={x['container_id'] for x in observations}
for file in (ROOT/'reconciliation').glob('*/hard-exit-*.json'):
 assert json.loads(file.read_text())['observation']['daemon_identity_sha256']==cleanup['daemon_identity_sha256']
for name in ('junit.xml','wheel-junit.xml','sdist-junit.xml'):
 cases=list(ET.parse(run/name).iter('testcase'));assert len(cases)==898
 actual=[c for c in cases if any(s in c.get('classname','') for s in ('test_docker_verifier','test_owner_execution','test_execution_reconciliation'))]
 assert len(actual)==26 and all(c.find('skipped') is None and c.find('failure') is None and c.find('error') is None for c in actual)
 cases_policy=[c for c in cases if 'test_verification_reconciliation' in c.get('classname','')]
 assert len(cases_policy)==43 and all(c.find('skipped') is None for c in cases_policy)
window=Path('D:/agentsync-debug/evidence/windows-c1f2e83-junit.xml');cases=list(ET.parse(window).iter('testcase'))
assert len(cases)==898 and sum(c.find('skipped') is not None for c in cases)==29
assert all(c.find('failure') is None and c.find('error') is None for c in cases)
helper=runpy.run_path(str(REPO/'tools/release_acceptance.py'))
helper['persist_junit'](window,ROOT/'windows-junit.xml')
safe,_=helper['redact_credentials'](Path('D:/agentsync-debug/evidence/windows-c1f2e83-pytest.log').read_text(encoding='utf-8-sig'))
(ROOT/'windows-pytest.log').write_bytes(safe.replace('\r\n','\n').encode())
snapshot=Path('D:/agentsync-debug/evidence/windows-c1f2e83-source-snapshot.json')
assert json.loads(snapshot.read_text())==json.loads((run/'source-snapshot.json').read_text())
(ROOT/'windows-source-snapshot.json').write_bytes(snapshot.read_bytes())
summary={'schema_version':1,'tested_commit_sha':SHA,'tested_tree_sha':TREE,'module_sha256':modules,'checks_passed':18,'local_only':True,'github_execution_used':False,'linux':{k:{'passed':895,'skipped':3} for k in ('source','wheel','sdist')},'windows':{'source':{'passed':869,'skipped':29}},'real_observations':{'backend':42,'owner_executor':21,'reconciliation':15,'total':78,'independent_exact_id_absence_checks':78,'cleanup_receipts_by_environment':receipts},'formal_release':'blocked','limitations':['Explicit one-shot owner cleanup observations only; original assessment remains unverified.','Actual executor process termination and DB reopen; lease expiry is injected into disposable fixture data.','No retry/resume of interrupted cleanup intents, no unknown/late-create recovery or historical daemon identity proof.','No task acceptance gate, approval consumption, safe apply or real client relay.','Policy fault injection is separate from actual Docker evidence.'],'observations':observations}
(ROOT/'inspection.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in summary.items() if k!='observations'},indent=2))
