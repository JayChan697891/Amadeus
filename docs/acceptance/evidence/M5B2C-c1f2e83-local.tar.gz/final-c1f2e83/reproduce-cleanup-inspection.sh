set -eu
/root/jobs-env/bin/python - <<'PY'
from pathlib import Path
import json,subprocess,re,hashlib
root=Path('/root/evidence/final-c1f2e83')
run=next((root/'collector').glob('release-*'))
report=json.loads((run/'report.json').read_text())
assert len(report['checks'])==18 and all(c['status']=='pass' for c in report['checks'])
ids=[]
for folder, count in (('docker',42),('owner-executor',21),('reconciliation',15)):
 files=list((root/folder).glob('*/*.json'));assert len(files)==count,(folder,len(files))
 for file in files:
  data=json.loads(file.read_text())
  ids.append(data['binding']['container_id'] if folder=='owner-executor' else data['container_id'])
assert len(ids)==len(set(ids))==78 and all(re.fullmatch('[0-9a-f]{64}',i) for i in ids)
absent=[]
for ident in ids:
 result=subprocess.run(['docker','inspect','--format','{{.Id}}',ident],capture_output=True,timeout=10)
 assert result.returncode==1 and not result.stdout.strip() and result.stderr.strip().lower()==b'error: no such object: '+ident.encode(),ident
 absent.append(ident)
daemon=subprocess.check_output(['docker','info','--format','{{.ID}}']).decode().strip()
(root/'cleanup-inspection.json').write_text(json.dumps({'inspected':78,'all_exact_container_ids_absent':True,'container_ids':absent,'daemon_identity_sha256':hashlib.sha256(daemon.encode()).hexdigest(),'method':'independent exact-full-ID docker inspect after all three suites; no removal issued'},indent=2))
source=Path('/root/final-c1f2e83/src/agentsync')
import agentsync
installed=Path(agentsync.__file__).parent
matched=[]
for file in source.rglob('*.py'):
 rel=file.relative_to(source);assert file.read_bytes()==(installed/rel).read_bytes(),str(rel)
 matched.append(str(rel))
(root/'source-install-module-binding.json').write_text(json.dumps({'module_files_matched':matched,'source_installation':'editable frozen checkout','source':str(source),'installed':str(installed)},indent=2))
print(json.dumps({'sha':report['commit_sha'],'checks_passed':18,'real_container_observations':78,'independent_exact_ids_absent':78}))
PY
tar -C /root/evidence -czf /root/final-c1f2e83-evidence.tar.gz final-c1f2e83
