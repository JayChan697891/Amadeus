from test_candidate_binding_git_records import prepared as prepared, world as world
from agentsync.verification.binding import OwnerCandidateBindings
from agentsync.storage.database import connect
from agentsync.errors import AgentSyncError
import pytest

def test_real_sqlite_failure_preserves_outer_transaction(prepared):
    core=prepared[0]
    service=OwnerCandidateBindings(core)
    args={**prepared[1], 'candidate_id':prepared[7]['candidate_id'], 'expected_candidate_sha':prepared[7]['candidate_sha']}
    before=service.capture(**args)
    db=connect(core.db_path)
    try:
        db.execute('BEGIN IMMEDIATE')
        db.execute('UPDATE tasks SET version=version+1 WHERE id=?',(before.left_task_id,))
        db.execute('ALTER TABLE merge_candidates RENAME TO audit_hidden_candidates')
        with pytest.raises(AgentSyncError) as exc:
            service._capture_in_transaction(db,**args)
        assert exc.value.code=='storage_error'
        assert 'audit_hidden_candidates' not in str(exc.value)
        assert db.in_transaction
        assert db.execute('SELECT version FROM tasks WHERE id=?',(before.left_task_id,)).fetchone()[0]==before.left_task_version+1
        assert db.execute('SELECT 1').fetchone()[0]==1
        db.rollback()
    finally:
        db.close()
    assert service.capture(**args)==before
