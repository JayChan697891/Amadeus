set -eu
docker info --format '{{.ServerVersion}}'
docker image inspect --format '{{.Id}}' sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
sha=37b17a3d0c27b0a34ca93e03c4944f02a7a63071
root=/root/final-37b17a3
mkdir -p /root/evidence/final-37b17a3
if [ ! -d "$root" ]; then git clone /root/source-binding-transaction.bundle "$root"; fi
cd "$root"
git checkout --detach "$sha"
test "$(git rev-parse HEAD)" = "$sha"
test -z "$(git status --porcelain)"
/root/jobs-env/bin/python -m pip install --no-deps -e .
export AGENTSYNC_DOCKER_TEST_IMAGE=sha256:34386ef0cb081344d7ec1c103ba398e6e9f64e9ab3a1509accc92a4e24a07258
export AGENTSYNC_REQUIRE_DOCKER_TESTS=1
export AGENTSYNC_VERIFIER_EVIDENCE_DIR=/root/evidence/final-37b17a3/docker
export AGENTSYNC_OWNER_EXECUTOR_EVIDENCE_DIR=/root/evidence/final-37b17a3/owner-executor
export AGENTSYNC_RECONCILIATION_EVIDENCE_DIR=/root/evidence/final-37b17a3/reconciliation
export AGENTSYNC_BINDING_EVIDENCE_DIR=/root/evidence/final-37b17a3/candidate-binding
export AGENTSYNC_CANDIDATE_INPUT_EVIDENCE_DIR=/root/evidence/final-37b17a3/candidate-input
/root/jobs-env/bin/python tools/release_acceptance.py --output /root/evidence/final-37b17a3/collector --run --package-install --sdist-install
